(function(win) {
  if (!win.addEventListener) return
  var html = document.documentElement
  function setFont() {
    function setRem() {
      // html.style.fontSize = '16px'
    }
    setRem()
    setTimeout(function() {
      setRem()
    }, 300)
  }
  win.addEventListener('resize', setFont, false)
  setFont()
  var originalHeight = document.documentElement.clientHeight || document.body.clientHeight
  window.onresize = function() {
    // 键盘弹起与隐藏都会引起窗口的高度发生变化
    var resizeHeight = document.documentElement.clientHeight || document.body.clientHeight
    // 1. 从app自身的Webview高度方面去考虑
    // if (resizeHeight - 0 < originalHeight - 0) { // resizeHeight<originalHeight证明窗口被挤压了
    //   plus.webview.currentWebview().setStyle({
    //     height: originalHeight // 强设置为原高度
    //   })
    // }
    // 2. 从h5自身角度去解决
    if (resizeHeight - 0 < originalHeight - 0) { // resizeHeight<originalHeight证明窗口被挤压了
      // 可以去操作dom 进行隐藏按钮  // xxx.style.display='none';
      // 隐藏的手段就有很多了 可以z-index为负数、opacity透明度等等
      document.getElementById('footer').style.zIndex = '-1'
    } else {
      // 还原按钮的显示 // xxx.style.display='';
      document.getElementById('footer').style.zIndex = '10'
    }
  }
})(window)

