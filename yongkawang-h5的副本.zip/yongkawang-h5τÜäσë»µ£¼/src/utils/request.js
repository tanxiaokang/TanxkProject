// 说明书
// 1封装的请求兼容get post，
// 2由于大项目中都用到了第三方，他的baseUrl是不一样的，做了第三方兼容
// 3由于有个需要token有的不需要，做了兼容
// 4有的需要跨域，做了兼容
// 5测试环境和线上不一样的baseUrl做了兼容
// 6支持表单和json提交

import axios from 'axios'
import qs from 'qs'
import Vue from 'vue'
const baseApi = {
  development: 'http://192.168.123.222:10003', // dejin
  // development: 'http://uat.runzezhihui.com:82/apate',
  // development: 'https://www.yongkawang.cn/gateway/rnjf-apate-h5',
  production: 'https://www.yongkawang.cn/gateway/rnjf-apate-h5',
  // production: 'https://www.yongkawang.cn/apate',
  // production: 'http://uat.runzezhihui.com:82/apate',
  // production: 'http://192.168.123.222:10003',
  testing: 'http://192.168.123.222:10003',
  uat: 'http://uat.runzezhihui.com:82/apate'
}
// process 对象是一个全局变量，它提供有关当前 Node.js 进程的信息并对其进行控制。无需使用 require()。
// process.env 属性返回包含用户环境的对象
const API_ENV = process.env.API_ENV

console.log(4, API_ENV)
export default function request(...params) {
  const T = {
    url: params[0].url || 0,
    data: params[0].data || 0,
    method: params[0].method || 'post',
    isToken: params[0].isToken || true,
    isFormStyle: params[0].isFormStyle || false,
    isJson: params[0].isJson || false,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    }
  }
  // console.log(T)
  var baseUrl = baseApi[API_ENV]
  Vue.$vux.loading.show({
    text: '加载中...'
  })
  // 对请求方式 get 和post 进行兼容
  if (T.method == 'get' || T.method == 'GET') {
    return new Promise((resolve, reject) => {
      var getURL = ''
      if ((T.url).indexOf('http') != -1) {
        getURL = T.url
      } else {
        getURL = baseUrl + T.url
      }
      axios.get(getURL, {
        params: T.data
      }).then(data => {
        Vue.$vux.loading.hide()
        const results = data.data
        resolve(results)
      })
    })
  } else {
    return new Promise((resolve, reject) => {
      if (T.isJson) {
        T.headers = {
          'Content-Type': 'application/json;charset=UTF-8'
        }
        T.data = JSON.stringify(T.data)
      } else {
        T.data = qs.stringify(T.data)
      }
      // 后期打开
      // if (T.isToken != 'noToken') {
      //   T.headers.token = localStorage.getItem('token')
      // }
      var URL = ''
      if ((T.url).indexOf('http') != -1) {
        URL = T.url
      } else {
        URL = baseUrl + T.url
      }
      axios.post(URL, T.data, {
        headers: T.headers
      }).then((data) => {
        const _data = data.data
        Vue.$vux.loading.hide()
        resolve(_data)
      }).catch(err => {
        console.log(err)
        Vue.$vux.loading.hide()
        Vue.$vux.toast.show({
          type: 'warn',
          text: '网络错误'
        })
      })
    })
  }
}

