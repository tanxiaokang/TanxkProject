
/* ---------------------------------------------------------
  //与原生 通信
  onclick="callShareClient('addressBook','s1s')"  //通讯录
  onclick="callShareClient('push','ssssssss')"    //第二个参数要传UserNo
  onclick="callShareClient('push','')"            //第二个参数必须为''
  onclick="callShareClient('location','s3s')"
   ----------------------------------------------------------*/
//  1.h5向客户端传参 h5调用app
// 客户端使用：Client，h5InvokeApp，参数a和b。参数a必须传addressBook, faceId ，push，location。参数b随意传
window.callShareClient = function(a, b) {
  if (window.Client) {
    return new Promise((resolve, reject) => {
      alert(进来了window.Client)
      resolve(window.Client.h5InvokeApp(a, b)) // app内处理逻辑

      reject('app js交互异常')
      console.log('in app')
    })
  } else {
    return new Promise((resolve, reject) => {
      console.log('!app登录')
      resolve('ok') // 在H5 内部处理逻辑
      reject('no')
      return
    })
  }
  // try {
  //   Client.h5InvokeApp(a, b)
  // } catch (error) {
  //   return new Promise((resolve, reject) => {
  //     console.log('!app登录')
  //     resolve('ok')
  //     reject('no')
  //     return
  //   })
  // }
}

// 2.客户端向h5传参   appInvokeH5
// dataClientForH5此方法必须写，客户端传数据，用此方法接收。两个参数都是json字符串， type是3个类型，根据不同的类型处理不同的事件
// window.appInvokeH5 = function(param, type) {
//   console.log(121, param, type)
//   return new Promise((resolve, rejact) => {
//     switch (type) {
//       case 'addressBook':
//         resolve({ type: type, data: param })
//         break
//       case 'push':
//         resolve({ type: type, data: param })
//         break
//       case 'location':
//         resolve({ type: type, data: param })
//         break
//       case 'faceId':
//         resolve({ type: type, data: param })
//         break
//     }
//   })
// }

