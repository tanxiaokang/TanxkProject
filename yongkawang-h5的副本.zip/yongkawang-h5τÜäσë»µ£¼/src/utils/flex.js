(function(win) {
  if (!win.addEventListener) return
  var html = document.documentElement
  function setFont() {
    function setRem() {
      var cliWidth = html.clientWidth
      var cliHeight = html.clientHeight
      var val = 375
      if (cliWidth > 750) {
        // 横屏
        cliWidth = 750
      }
      var f_s = cliWidth / val * 100
      html.style.fontSize = f_s + 'px'
      // console.log(100, f_s)
    }
    setRem()
    setTimeout(function() {
      setRem()
    }, 300)
  }
  win.addEventListener('resize', setFont, false)
  setFont()
})(window)
