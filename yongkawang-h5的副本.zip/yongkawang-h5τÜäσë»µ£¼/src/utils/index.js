export function getUrlQueryObj() {
  var localhref = window.location.href
  // console.log(56, localhref)
  var tempObj = {}
  if (localhref.lastIndexOf('?') > -1) {
    var queryStr = localhref.substr(localhref.lastIndexOf('?') + 1)
    var localarr = queryStr.split('&')
    for (var i = 0; i < localarr.length; i++) {
      tempObj[localarr[i].split('=')[0]] = localarr[i].split('=')[1]
    }
  }
  // console.log(11, tempObj)
  return tempObj
}
