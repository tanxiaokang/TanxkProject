export default {
  data() {
    return {
      myMoney: 1000,
      bindStatus: 0,
      moneyDialogFlag: 0,
      dialogFlag: false
    }
  },
  methods: {
    // 提现流程
    extract() {
      // 先判定金额大小
      if (this.myMoney < 100) {
        this.dialogFlag = true
      } else {
        // 再判定绑卡状态
        if (!this.bindStatus) {
          // 这里去绑卡
          this.$router.push({ path: '/bindCard', query: {
            mobile: this.selfM,
            userNo: this.userNo,
            token: this.token
          }})
        } else {
          // 显示提现弹窗
          this.moneyDialogFlag = 1
          this.dialogFlag = true
        }
      }
    },
    // 关闭提现弹窗
    closeDialog(val) {
      this.dialogFlag = val
    },
    // 通知app
    h5toNative(type, params) {
      try {
        Client.callBackDataH5ForClient(type, params)
      } catch (error) {
        this.$vux.toast.show({
          text: `请在用卡王App内操作`,
          type: 'warn',
          width: '11em'
        })
      }
    }
  }
}
