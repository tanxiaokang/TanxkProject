
export default {
  data() {
    return {

    }
  },
  methods: {
    jumpToapplyOrDoor(prams, channel, form, cid, bankId, applySource, netApplyAddress, creditNo, flag, rewardMoney, assembleNo, assembleType, userNo, assembles) {
      const _prams = Number(prams)
      alert('跳线上还是线下')
      switch (_prams) {
        case 1: // 1网申
          this.$router.push({
            path: './applyCard',
            query: {
              form: form,
              channel: channel,
              cid: cid,
              bankId: bankId,
              applySource: applySource,
              netApplyAddress: netApplyAddress,
              creditNo: creditNo,
              flag: flag,
              rewardMoney: rewardMoney,
              assembleNo: assembleNo,
              assembleType: assembleType,
              userNo: userNo,
              assembles: assembles
            }
          }); break
        case 2: // 上门办理
          this.$router.push({
            path: './applyCreditcard',
            query: {
              form: form,
              channel: channel,
              cid: cid,
              bankId: bankId,
              applySource: applySource,
              netApplyAddress: netApplyAddress,
              creditNo: creditNo,
              flag: flag,
              rewardMoney: rewardMoney,
              assembleNo: assembleNo,
              assembleType: assembleType,
              userNo: userNo,
              assembles: assembles
            }
          }); break

        default:this.$router.push({
          path: './applyCreditcard',
          query: {
            form: form,
            channel: channel,
            cid: cid,
            bankId: bankId,
            applySource: applySource,
            netApplyAddress: netApplyAddress,
            creditNo: creditNo,
            flag: flag,
            rewardMoney: rewardMoney,
            assembleNo: assembleNo,
            assembleType: assembleType,
            userNo: userNo,
            assembles: assembles // 0 不拼团  1 拼团
          }
        }); break
      }
    }
  }
}
