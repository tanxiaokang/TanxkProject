import wx from 'weixin-js-sdk'
import { getWXConfigSignature } from '@/api'
import { start } from '@/api/assemble-controller.js'
export default {
  data() {
    return {
      local: {
        mes: ''
      }
    }
  },
  methods: {
    // 微信2次分享
    getWxShare(sharedesc) {
      wx.checkJsApi({
        jsApiList: ['updateAppMessageShareData', 'updateTimelineShareData'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
        success: function(res) {}
      })
      const params = {}
      params.url = (window.location.href)
      getWXConfigSignature(params).then(res => {
        this.$uweb.trackEvent(sharedesc.desc, '分享')
        if (res.code == 1) {
          this.local.mes = res.resultObj
          this.$vux.loading.hide()
          wx.config({
            debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: this.local.mes.appId, // 必填，公众号的唯一标识
            timestamp: this.local.mes.timestamp, // 必填，生成签名的时间戳
            nonceStr: this.local.mes.nonceStr, // 必填，生成签名的随机串
            signature: this.local.mes.signature, // 必填，签名
            jsApiList: ['updateAppMessageShareData', 'updateTimelineShareData', 'onMenuShareTimeline', 'onMenuShareAppMessage'] // 必填，需要使用的JS接口列表
          })
          wx.ready(function() { // 需在用户可能点击分享按钮前就先调用
            const obj = sharedesc
            wx.updateAppMessageShareData(obj)
            wx.updateTimelineShareData(obj)
            wx.onMenuShareTimeline(obj)
            wx.onMenuShareAppMessage(obj)
          })
        }
      })
    },
    // 判断是否是pc 端登录
    isPC() {
      var userAgentInfo = navigator.userAgent
      var Agents = ['Android', 'iPhone',
        'SymbianOS', 'Windows Phone',
        'iPad', 'iPod']
      var flag = true
      for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
          flag = false
          break
        }
      }
      return flag
    },
    // 判断手机
    isMobile() {
      var u = navigator.userAgent
      var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1 // g
      var isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) // ios终端
      let channel
      if (isAndroid) {
        // 这个是安卓操作系统
        channel = 'App-Andior' // 参数异常
      }
      if (isIOS) {
        // 这个是ios操作系统
        channel = 'App-Ios' // 不能写死
      }
      return channel
    }

  }
}
