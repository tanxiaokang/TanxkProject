<template lang='pug'>
x-dialog(
      :dialog-style="{'max-width': '100%', width: '100%', height: '50%', 'background-color': 'transparent'}"
      :hide-on-blur="false"
      v-model="dialogFlag")
  div.active-dialog
    div.dialog-bg
      img.full-img(src='@/assets/bg-tanchu.png')
    div.dialog-c
      div.a-content(v-if='dialogType==0')
        |提现金额不足100元
        br
        |暂时不能提现,继续邀请好友吧
      div.a-content(v-else)
        //- x-number(v-model="oeditMoney" button-style="round" :min="0" :max="9999")
        br
        span(style='fons-size:24px;')|提现: {{editMoney}} 元
        br
      div.a-button.a-btn-color(
        @click='handleClick'
        style="width:2.6rem;height:40px;font-size:17px;line-height:40px;margin:0 auto;border-radius:20px")|确定
</template>
<script>
import { XDialog, XNumber } from 'vux'
export default {
  components: {
    XDialog,
    XNumber
  },
  props: {
    dialogFlag: {
      type: Boolean,
      default: false
    },
    dialogType: {
      type: Number,
      default: 0
    },
    editMoney: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      oeditMoney: 0
    }
  },
  created() {
    this.oeditMoney = this.editMoney
  },
  methods: {
    handleClick() {
      if (this.dialogType) {
        this.$emit('submitMoney', this.editMoney)
      } else {
        this.$emit('closeDialog', false)
      }
    }
  }
}
</script>
<style lang="less" scoped>
.active-dialog{
  position: relative;
  box-sizing: border-box;
  margin: 0 auto;
  width: 3rem;
  color: #FFFFFF;
  border-radius: 15px;
  .dialog-bg{
    position: absolute;
    width: 3.1rem;
    height: 2rem;
    top: 0;
    left: -.05rem;
  }
  .dialog-c{
    position: absolute;
    width: 100%;
    top: .7rem;
    left: 0;
    z-index: 10;
  }
  .a-content{
    font-weight: 300;
    text-align: center;
    line-height: 22px;
    font-size: 16px;
    margin-bottom: 30px;
  }
  .a-btn-color{
    background-image: linear-gradient(left,#C046F0,#CE23C5);
    background: -webkit-linear-gradient(left,#C046F0,#CE23C5);
    color:#ffffff;
    display: flex;
    justify-content: center;
  }
}

</style>
