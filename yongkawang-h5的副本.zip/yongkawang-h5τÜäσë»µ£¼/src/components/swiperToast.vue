<template>
  <div :showTime="showTime" class="swiper-toast">
    <ul>
      <li class="swiper-toast-li">
        <img src="@/assets/assemble/swiper.png" alt="">
        {{ dataObj.mobile }}用户开卡成功，将获得{{ dataObj.rewardMoney | parseRewardMoney }}元现金红包
        <slot />
      </li>
    </ul>
  </div>
</template>
<script>
import { setInterval } from 'timers'
export default {
  name: 'SwiperToast',
  filters: {
    parseRewardMoney(val) {
      return parseInt(val)
    }
  },
  props: {
    dataObj: {
      type: Object
    },
    showTime: {
      type: Number,
      default: 2
    },
    hideTime: {
      type: Number,
      default: 6
    }

  },
  data() {
    return {

    }
  },
  created() {
    setInterval(() => {
      this.showTime = true
    }, 6000)
  }
}
</script>
<style lang="less" scoped>

.swiper-toast{
    position: absolute;
    top:41px;
    background: rgba(59,66,87,.8);
    padding:4px 8px;
    border-radius: 8px;
    color: #ffffff;
    font-size: 12px;
    left: 45px;
    &-li{
        list-style: none;
        img{
            width:14px;
            height: 14px;
            vertical-align: middle;
        }
    }
}
    @keyframes fadeIn {
        0%    {opacity: 0}
        100%  {opacity: 1}
    }
    @-webkit-keyframes fadeIn {
        0%    {opacity: 0}
        100%  {opacity: 1}
    }
    @-moz-keyframes fadeIn {
        0%    {opacity: 0}
        100%  {opacity: 1}
    }
    @-o-keyframes fadeIn {
        0%    {opacity: 0}
        100%  {opacity: 1}
    }
    @-ms-keyframes fadeIn {
        0%    {opacity: 0}
        100%  {opacity: 1}
    }
    /*设置三帧让动画消失得更平缓*/
    @keyframes fadeOut {
        0%    {opacity: 1}
        60%     {opacity: .9}
        100%  {opacity: 0}
    }
    @-webkit-keyframes fadeOut {
        0%    {opacity: 1}
        60%     {opacity: .9}
        100%  {opacity: 0}
    }
    @-moz-keyframes fadeOut {
        0%    {opacity: 1}
        60%     {opacity: .9}
        100%  {opacity: 0}
    }
    @-o-keyframes fadeOut {
        0%    {opacity: 1}
        60%     {opacity: .9}
        100%  {opacity: 0}
    }
    @-ms-keyframes fadeOut {
        0%    {opacity: 1}
        60%     {opacity: .9}
        100%  {opacity: 0}
    }
    .fadeOut{
        animation: fadeOut 1s;
    }
    .fadeIn{
        animation:fadeIn 1s;
    }
</style>
