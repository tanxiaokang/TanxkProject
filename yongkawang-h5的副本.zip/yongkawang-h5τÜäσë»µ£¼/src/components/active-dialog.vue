<template lang='pug'>
x-dialog(
      :dialog-style="{'max-width': '100%', width: '100%', height: '50%', 'background-color': 'transparent'}"
      :hide-on-blur="false"
      v-model="dialogFlag")
  div.active-dialog
    div.a-title 提现
    div.a-content(v-if='dialogType == 0')
      |提现金额不足100元，暂时不能提现
      br
      |继续去邀请好友吧～
    div.a-content(v-else)
      |金额:{{editMoney}}
    div.a-button.a-btn-color(
      @click='handleClick'
      style="width:100%;height:40px;font-size:17px;line-height:40px;margin:0 auto;border-radius:20px")|确定
</template>
<script>
import { XDialog } from 'vux'
export default {
  components: {
    XDialog
  },
  props: {
    dialogFlag: {
      type: Boolean,
      default: false
    },
    dialogType: {
      type: Number,
      default: 0
    },
    editMoney: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
    }
  },
  methods: {
    handleClick() {
      if (this.dialogType) {
        this.$emit('submitMoney', this.editMoney)
      } else {
        this.$emit('closeDialog', false)
      }
    }
  }
}
</script>
<style lang="less" scoped>
.active-dialog{
  box-sizing: border-box;
  margin: 0 auto;
  width: 3rem;
  padding:20px;
  color: #FFFFFF;
  background: #FF6F61;
  border-radius: 15px;
  .a-title{
    text-align: center;
    font-size: 20px;
    line-height: 28px;
    margin-bottom: 20px;
  }
  .a-content{
    font-weight: 300;
    text-align: center;
    line-height: 22px;
    font-size: 16px;
    margin-bottom: 30px;
  }
  .a-btn-color{
    background-image: linear-gradient(left,#FFEAC7,#EFCB9F);
    background:-webkit-linear-gradient(left,#FFEAC7,#EFCB9F);
    color:#FF6F61;
    display: flex;
    justify-content: center;
  }
}

</style>
