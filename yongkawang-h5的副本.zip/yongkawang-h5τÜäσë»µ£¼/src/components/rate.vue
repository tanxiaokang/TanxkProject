<!--评分-->
<template>
  <div class="rate" :class="{'disabled':disabled}" style="display:flex;">
    <div
      v-for="(i,id) in 5"
      :key="id"
      class="fire"
      :class="getClass(i)"
      style="width:10px;height:13px;"
      @mouseenter="disabled?'':curScore=i"
      @mouseleave="disabled?'':curScore=''"
      @click="disabled?'':setScore(i)"
    >
      <div v-if="disabled && i == Math.floor(score)+1" :style="'width:'+width" />
    </div>
    <span v-if="showText" class="text">{{ curScore||score }}分</span>
  </div>
</template>

<script>
export default {
  name: 'MyRate',
  props: {
    score: {
      type: Number,
      default: 0
      // required: true
    },
    disabled: {
      type: Boolean,
      default: false
    },
    showText: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      curScore: '',
      width: ''
    }
  },
  created: function() {
    this.getDecimal()
  },
  methods: {
    getClass(i) {
      if (this.curScore === '') {
        return i <= this.score ? 'fire-red' : 'fire-gray'
      } else {
        return i <= this.curScore ? 'fire-red' : 'fire-gray'
      }
    },
    getDecimal() {
      this.width = Number(this.score * 100 - Math.floor(this.score) * 100) + '%'
    },
    setScore(i) {
      this.$emit('update:score', i)// 使用`.sync`修饰符，对score 进行“双向绑定
    }
  }
}
</script>
<style scoped>
    .fire{
        background: url('../assets/assemble/icon_fire_gray.png') no-repeat center center;
        background-size: 100% 100%;
    }
    .fire-red{
        background: url('../assets/assemble/icon_fire_red.png') no-repeat center center;
         background-size: 100% 100%;
    }
    .fire-gray{
        background: url('../assets/assemble/icon_fire_gray.png') no-repeat center center;
         background-size: 100% 100%;
    }
</style>
