
<template>
  <div id="app">
    <KeepAlive>
      <RouterView v-if="$route.meta.keepAlive" />
    </KeepAlive>
    <RouterView v-if="!$route.meta.keepAlive" :key="$route.fullPath" />
  </div>
</template>

<script>

export default {
  name: 'App'
}
</script>

<style lang="less">
  @import '~vux/src/styles/reset.less';

</style>
