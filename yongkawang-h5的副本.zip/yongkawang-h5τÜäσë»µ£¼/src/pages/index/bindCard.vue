
<template lang='pug'>
  div.page-container
    div.bankform-container
      group(label-width='78' label-align='left' :gutter='0')
        x-input(
          required
          title="姓名"
          v-model="userName"
          placeholder="请输入您的姓名")
        x-input(
          required
          title="身份证号"
          v-model="idCard"
          placeholder="请输入您的身份证号")
        cell(title="银行"  value-align='left' is-link @click.native='showBankList')
          div(:class="{'bank-color':bankNameCom !='请选择发卡银行'}" style='font-weight:300')|{{bankNameCom}}
        x-input(
          required
          title="银行卡号"
          v-model="bankCard"
          placeholder="请输入您的银行卡号")

      group(label-width='78' label-align='left' :gutter='10')
        x-input(
          required
          title="手机号"
          v-model="mobile"
          placeholder="请输入您的手机号码")
        x-input(
          type='tel'
          title="验证码"
          v-model="vcode"
          placeholder="请输入手机验证码"
          :show-clear='false'
          :max='6'
          )
            div(slot='right')
              div.vbtn(@click='sendCode' v-if='!start') 发送验证码
              div.vbtn.vbtn-disabled(v-else)
                |重新发送&nbsp;
                countdown( v-model="time" :start="start" @on-finish="finish")
      div.btn-color.btn(
        @click='submit'
        style='width:3.35rem;height:40px;font-size:18px')|完成
    popup(
      v-model="popupFlag"
      height="100%"
      position='bottom'
      :hide-on-blur='false')
      popup-header(
        left-text="取消"
        right-text="确定"
        title="请选择银行"
        :show-bottom-border="false"
        @on-click-left="popupFlag = false"
        @on-click-right="popupFlag = false")
      group(:gutter='0')
        cell(v-for='item in bankList' :title='item.bankName' :key='item.bankCode' is-link @click.native='emitBank(item)')

</template>

<script>
import '@/utils/flex.js'
import { XInput, Group, Cell, Countdown, Popup, PopupHeader } from 'vux'
import { bindBankCardBank, bindBankCardBind, bindBankCardCodeResend, verify } from '@/api'
export default {
  name: 'App',
  components: {
    XInput,
    Group,
    Cell,
    Countdown,
    PopupHeader,
    Popup
  },
  data() {
    return {
      userName: '',
      idCard: undefined,
      bankCard: undefined,
      bankCode: undefined,
      bankName: undefined,
      mobile: undefined,
      vcode: undefined,

      popupFlag: false,

      time: 45,
      start: false,
      bankList: [],
      ticket: undefined
    }
  },
  computed: {
    bankNameCom() {
      return this.bankName || '请选择发卡银行'
    }
  },
  created() {
    this.mobile = this.$route.query.mobile
    this.init()
  },
  mounted() {},
  methods: {
    init() {
      bindBankCardBank().then(res => {
        this.bankList = res.data
      })
    },
    emitBank(item) {
      this.bankName = item.bankName
      this.bankCode = item.bankCode
      this.popupFlag = false
    },
    showBankList() {
      this.popupFlag = true
    },

    sendCode() {
      if (this.ticket) {
        // 重发短信逻辑
        bindBankCardCodeResend(this.ticket).then(res => {
          if (res.errorCode == '0000') {
            this.$vux.toast.text({
              type: 'success',
              text: '重新发送成功'
            })
            this.start = true
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.errorMessage
            })
          }
        })
      } else {
        // 预绑卡发短信
        const params = {}
        params.bankCard = this.bankCard
        params.bankCode = this.bankCode
        params.cardMobile = this.mobile
        params.cardType = 1
        params.client_ip = ''
        params.idCard	 = this.idCard
        params.trueName = this.userName
        params.validityPeriod = ''
        params.verificationValue = ''
        // 酷宝绑卡接口
        bindBankCardBind(params).then(res => {
          if (res.errorCode == '0000') {
            this.$vux.toast.show(
              {
                text: '发送成功',
                type: 'success'
              })
            this.ticket = res.data.ticket
            this.start = true
          } else {
            this.start = true
            this.$vux.toast.show({
              type: 'cancel',
              text: res.errorMessage
            })
          }
        })
      }
    },
    finish() {
      this.start = false
      this.time = 45
    },
    submit() {
      const params = {}
      params.clientIp = ''
      params.code = this.vcode
      params.tiket = this.ticket
      verify(params).then(res => {
        if (res.errorCode == '0000') {
          console.log('绑卡成功')
        } else {
          this.$vux.toast.show({
            type: 'cancel',
            text: res.errorMessage
          })
        }
      })
    }
  }
}
</script>

<style lang="less">
  @import '~vux/src/styles/reset.less';
  @import '../../style/theme-color';
  @media screen and (min-width: 520px) {

  }
  .bankform-container{
  position: absolute;
  background: #F8F8F8;
  width: 100%;
  top: 0;
  bottom: 0;
  }
  .bank-color{
    color: #000000;
  }
  .btn-color{
      background-image: linear-gradient(left,@theme-main-color,#E04839);
      background: -webkit-linear-gradient(left,@theme-main-color,#E04839);
      color:#FFFFFF;
      display: flex;
      justify-content: center;
      align-items: center;
    }
  .btn{
    margin:15px auto;
    border-radius: 20px;
  }
  .vbtn{
    background: @theme-main-color;
    height: 24px;
    line-height: 24px;
    border-radius: 12px;
    color: #ffffff;
    font-size: 12px;
    padding: 0 10px;
  }
  .vbtn-disabled{
    background: #b3b3b3
  }

</style>
