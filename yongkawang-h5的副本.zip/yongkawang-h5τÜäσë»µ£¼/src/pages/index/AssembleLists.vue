<template class="container">
  <transition name="slide-left">
    <div class="lists-container">
      <div v-for="(item,ind) in lists" :key="ind" class="flex lists-list">
        <div class="msg">
          <img src="@/assets/assemble/hlogo.png" alt="" style="width:30px;height:30px;vertical-align:middle;">
          <span>{{ item.leaderMobile |parseMobile }}</span>
        </div>

        <div style="width:1.34rem;" class="desc">
          <p>还差<span class="red">{{ item.completionNum-item.currentNum }}</span>人成团</p>
          <p style="display: flex;float: right;">
            距离结束还剩<span><count-down
              style="line-height:18px;"
              class="countdown"
              :current-time="nowTime"
              :start-time="nowTime"
              :end-time="Number(item.endTime)"
              :tip-text="''"
              :tip-text-end="'距离结束还剩'"
              :end-text="'已结束'"
              :day-txt="''"
              :hour-txt="':'"
              :minutes-txt="':'"
              :seconds-txt="''"
              @start_callback="countDownS_cb(1)"
              @end_callback="countDownE_cb(1)"
            /></span>
          </p>
        </div>
        <div class="public-btn" @click="handleJoin(item.isNetApply, item.assembleNo)">
          加入拼团
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
import { getUrlQueryObj } from '@/utils/index.js'
import CountDown from 'vue2-countdown'
import showList from './component/showList.vue'
import utils from '@/utils/utils.js'
import { Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup } from 'vux'
import '@/utils/flex.js'
import mixins from '@/mixins/applyOrdoor.js'
import index from '@/mixins/index.js'
import { assembleNum, start } from '@/api/assemble-controller.js'
export default {
  name: 'Sign',
  components: {
    Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup, showList, CountDown
  },
  filters: {
    parseMobile(val) {
      return val.substr(0, 3) + '****' + val.substr(7, 11)
    }
  },
  mixins: [mixins, index],
  data() {
    return {
      time: '',
      lists: [],
      local: {
        creditNo: ''
      },
      nowTime: new Date().getTime(),
      localObj: {}
    }
  },
  created() {
    this.setDocumentTitle('正在拼团')
    this.local.creditNo = this.$route.query.creditNo
    this.init()
    this.localObj = getUrlQueryObj()
    console.log('参数拼接', this.localObj)
  },
  mounted() {
    setInterval(() => {
      this.time = utils.changeTimeStamp(1562427531)
    }, 1)
  },
  methods: {
    handleJoin(prams, assembleNo) {
      //  根据参数判断 是进入 上门办理 还是 网申3要素
      const pc = this.isPC()
      const bankId = this.localObj.bankId
      const applySource = this.localObj.applySource
      const netApplyAddress = this.localObj.netApplyAddress
      const creditNo = this.localObj.creditNo
      const flag = 1 // 查看全部 默认 是参与拼团
      const rewardMoney = this.localObj.rewardMoney
      const cid = this.localObj.cid
      
      let channel
      if (pc) {
        channel = 'H5-PC-ykw'
      } else {
        channel = this.isMobile()
      }
      // prams, channel, form, cid, bankId, applySource, netApplyAddress, creditNo, flag, rewardMoney
      this.jumpToapplyOrDoor(prams, channel, 'ykw', cid, bankId, applySource, netApplyAddress, creditNo, flag, rewardMoney, assembleNo)
    },
    init() {
      const obj = {}
      obj.pageSize = 1
      obj.rows = 10
      assembleNum(this.local.creditNo, obj).then(res => {
        if (res.code == 1) {
          this.lists = res.resultObj.resultObj
        }
      })
    },
    countDownE_cb: function(x) {
      console.log(2, x)
    },
    countDownS_cb: function(x) {
      console.log(1, x)
    }
  }
}
</script>

<style lang="less" scoped>
@import '~vux/src/styles/reset.less';
@fontSizeColor:#3B4257;
.container{
  overflow-x: hidden;
}
.lists-container{
    padding:27px 16px 0;
    font-size: 12px;
    color: @fontSizeColor;
    .lists-list{
        margin-bottom:34px;
    }
    .msg{
        color: @fontSizeColor;
        font-weight: 400;
    }
    .desc{
        text-align: right;
        color: @fontSizeColor;
         font-weight: 400;
    }
    .public-btn{
        text-align: center;
        color: #fff;
        background: #F4402E;
        font-size: 14px;
        width:.7rem;
        height: .26rem;
        line-height: .26rem;
        border-radius: 20px;
    }
}
.red{
  color: #F4402E;
}
.flex{
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.content{
    background: #FFD400;
    padding-top: 10px;
    &-wrap{
      width:3.43rem;
      margin:0 auto 16px;
      background: #fff;
      padding-top:0.16rem;
      padding-bottom:.28rem;
      border-radius: 10px;
      &-title{
        padding-right:14px;
        display: flex;
        justify-content: space-between;
      }
      &-imgs{
        width:3.43rem;
      margin:19px auto 0 auto;
      display: flex;
      justify-content: space-around;
      &-div{
        width:0.96rem;
      border:1px solid red;
        // height:1.43rem;
      }
    }
    }
.arrow{
  display: inline-block;
  width:10px;
  height:10px;
  border-top:1px solid #161921;
  border-right:1px solid #161921;
  -webkit-transform: translate(0,0%) rotate(45deg);
  transform: translate(0,0%) rotate(45deg);
}
.footer{
  text-align: center;
  color: #333333;
  font-size: 12px;
  padding-bottom:18px;
  margin-top:19px;
}
  }

</style>
<style scoped>
slide-right-enter-active,
.slide-right-leave-active,
.slide-left-enter-active,
.slide-left-leave-active {
  will-change: transform;
  transition: all 500ms;
  position: absolute;
}
.slide-right-enter {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}
.slide-right-leave-active {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-enter {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-leave-active {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}

</style>
