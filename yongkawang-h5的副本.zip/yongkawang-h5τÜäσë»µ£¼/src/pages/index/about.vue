
<template lang='pug'>
div#app
  div.page-container
    div
      img(
        style='width:100%'
        src='@/assets/brand-banner.png'
      )
    div
      img(
        style="width:100%"
        src='@/assets/brand-icon.png'
      )
    div.content-wrap
      div(style='padding:26px 17px;background:#ffffff')
        div.title
          i
          span|价值主张
          i
        p|用卡王为70、80、90后群体提供一站式的信用卡管理解决方案，更有品质、更安全、更及时的让用户享受信用生活 。
        p|用卡王不仅提供个性化推荐白金信用卡，专属经理上门指导办卡，快速提高信用卡额度等服务。而且，为用户提供一站式的用户养卡服务。
</template>

<script>
import '@/utils/flex.js'
export default {
  name: 'About',
  data: function() {
    return {

    }
  }
}
</script>

<style lang="less">
@import '~vux/src/styles/reset.less';
.page-container{
  position: absolute;
  top: 0;
  bottom:0;
  left:0;
  right: 0;
  background:#f5f5f5
}
.content-wrap{
  box-sizing: border-box;
  padding:15px;
  color: #666666;
  font-size: 14px;
  line-height: 20px;
  .title{
    font-weight: 500;
    height: 24px;
    line-height: 24px;
    display: flex;
    color: #333333;
    font-size: 17px;
    justify-content: center;
    align-items: center;
    margin-bottom: 15px;
    i{
      display: inline-block;
      margin: 0 12px;
      width:34px;
      height: 1px;
      background: #999999;
    }
  }
  p{
    margin-bottom: 10px;
  }
}

</style>
