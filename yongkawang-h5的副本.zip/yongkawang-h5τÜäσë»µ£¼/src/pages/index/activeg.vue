<template lang='pug'>
    div.group-wrap.page-container
      div.top
        img(
          :src="groupBg"
          style='width:3.75rem'
        )
      div.content
        //-app可见
        div.block.c-top(style="height:.6rem;")
          div.c-t-left(style="margin-left:.1rem;")
            div.money(style="font-size:16px;color:#333333;line-height:16px;margin-bottom:10px;")|{{myMoney}}元
            div(style="font-size:12px;color:#666666;line-height:12px;")|我的奖励
          div.c-t-right
            div.btn-color(
              @click='extract'
              style="width:.6rem;height:.2rem;margin-right:.1rem;border-radius:.1rem;font-size:12px;line-height:.2rem")|提现

        //- 全部可见
        div.block(style="padding:20px 17px;box-sizing:border-box;font-size:14px;line-height:26px")
          div.title-c(style="font-size:18px;")|活动规则
          div.title-c(v-for="item in active") {{item.title}}
            div(v-if='item.children.length!=0' v-for='i in item.children') {{i}}

        //- 按钮 app可见
        div
          div.btn-color(
            @click='share'
            style="width:3.35rem;height:40px;font-size:17px;line-height:40px;margin:0 auto;border-radius:20px")|立即邀请
      active-dialog(
        @submitMoney='submitMoney'
        :dialogType='moneyDialogFlag'
        @closeDialog='closeDialog'
        :editMoney='myMoney'
        :dialogFlag='dialogFlag')

</template>

<script>
import '@/utils/flex.js'
import { XInput, Countdown } from 'vux'
import activeDialog from '@/components/active-dialog.vue'
import { checkActivity, getActiveInfo, getUserBackList, withdraw } from '@/api'
import activeMixin from '@/mixins/active-mixin'
export default {
  name: 'App',
  components: {
    XInput,
    Countdown,
    activeDialog
  },
  mixins: [activeMixin],
  data: function() {
    return {
      active: [
        {
          title: '1.拼团奖励规则：',
          children: [
            '(1)拼团人数为1<X≤5，开卡激活成功，开卡成功用户每人可得30元；',
            '(2)拼团人数为5<X≤10，开卡激活成功，开卡成功用户每人可得50元；',
            '(3)拼团人数为10<X，开卡激活成功，开卡成功用户每人可得100元；',
            '(4若发起日1天无用户拼团（即被邀请用户没有申请信用卡），则拼团失效；自发起日起两周内所有拼团用户激活卡片成功才表示拼团成功。'
          ]
        },
        { title: '2.红包奖励发放后，将发放到用户的账户中，可进行绑卡提现；', children: [] },
        { title: '3.奖励上限为100元；', children: [] },
        { title: '4.同一用户邀请开卡得奖励和拼单办卡赢奖励两个活动只能参与一个。', children: [] },
        { title: '5.本活动规则最终解释权为用卡王所有。', children: [] }
      ],
      descArr: [
        '最全信用卡卡库',
        '白金卡90%通过率',
        '最新信用卡优惠活动',
        '智能提额工具'
      ],
      isApp: true,
      inviteM: undefined,
      selfM: undefined,
      path: '',
      bankCardNo: undefined,

      // 验证码
      time: 45,
      start: false,
      groupBg: require('@/assets/bg-group.png')

    }
  },
  computed: {

  },
  created() {
    const _urlQueryObj = this.$route.query
    this.selfM = _urlQueryObj.selfM
    this.userNo = _urlQueryObj.un
    this.token = _urlQueryObj.token
    this.init()
    this.genPath()
  },
  methods: {
    init() {
      // 获取用户可提现金额
      getActiveInfo(this.userNo).then(res => {
        this.myMoney = res.resultObj
      })

      // 获取用户绑卡列表, 更改绑卡状态
      getUserBackList(this.selfM).then(res => {
        console.log(res)
        if (res.errorCode == '0000') {
          this.bindStatus = 1
          this.bankCardNo = res.data[0].bankCard
        } else {
          // 未绑定银行卡
          this.bindStatus = 0
        }
      })
    },
    genPath() {
      const _path = location.href.split('#/')[0]
      this.path = _path
    },
    share() {
      // 分享前查询活动资格
      const params = {}
      params.mobile = this.selfM
      params.type = 2
      checkActivity(params).then(res => {
        if (res.code == 1) {
          this.commitshare()
        } else {
          console.log(res)
          this.$vux.toast.show({
            type: 'cancel',
            text: res.message,
            width: '14em'
          })
        }
      })
    },
    commitshare() {
      try {
        const params = {}
        params.url = this.path + '#/' + 'activeg-share?inviteM=' + this.selfM
        params.imageURL = this.path + this.groupBg
        params.subtitle = '用卡王App组团办卡月入十万'
        params.title = '组团办卡得奖励'
        console.log(params)
        this.h5toNative('share', JSON.stringify(params))
      } catch (error) {
        this.$vux.toast.show({
          text: '页面参数有误',
          type: 'warn'
        })
      }
    },
    submitMoney(money) {
      const params = {}
      params.money = money
      params.accountNo = this.userNo
      params.bankCard = this.bankCardNo
      withdraw(params)
        .then(res => {
          this.dialogFlag = false
          this.$vux.toast.show({
            type: res.code == 1 ? 'success' : 'cancel',
            text: res.message
          })
        })
        .catch(error => {
          console.log(error)
          this.dialogFlag = false
        })
    }
  }
}
</script>

<style lang="less">
  @import '~vux/src/styles/reset.less';
  @media screen and (min-width: 520px) {

  }
  .page-container{
    width: 3.75rem;
    margin: 0 auto;
  }
  .title-c{
    color:#363636;
    div{
      color:#868686
    }
  }
  .group-wrap{
    background-image: linear-gradient(top,#00C2FF,#8525E2);
    background:-webkit-linear-gradient(top,#00C2FF,#8525E2);
  }

  .content{
    box-sizing: border-box;
    position: relative;
    margin-top:-.4rem;
    padding-bottom: 20px;
    width: 100%;
    .block{
      width: 3.45rem;
      border-radius: 10px;
      margin: 0 auto;
      background:#FFFBF5;
      margin-bottom:15px;
    }
    .c-top{
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
  .btn-color{
    background-image: linear-gradient(left,#FF6F61,#E04839);
    background: -webkit-linear-gradient(left,#FF6F61,#E04839);
    color:#FFFFFF;
    display: flex;
    justify-content: center;
  }
  .dest-top{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    >div{
      width: 50%;
    }
  }
  .chameleon{
    position: relative;
    margin: 5px 0 5px;
    img{
      position: absolute;
      top: 4px;
      left: .14rem;
      width: 11px;
      height: 11px;
    }
    span{
    margin-left:.3rem;
    background-image: linear-gradient(to right, #C49A54, #9D692C);
    background: -webkit-linear-gradient(to right, #C49A54, #9D692C);
    background-clip: text;
    -webkit-background-clip: text;
    color: transparent;
    }
  }
</style>
