<template class="container">
  <!-- <transition name="slide-left"> -->
  <div class="sign-container">
    <div style="width:3.75rem;">
      <div>
        <img src="@/assets/assemble/header.png" alt="" style="width:100%;vertival-align:top;">
        <!-- <swiper
            v-if="swiperShow"
            auto
            height="22px"
            direction="vertical"
            :interval="4000"
            class="text-scroll"
            :show-dots="false"
            style=" position: absolute;
          width:290px;
          line-height:22px;
          top:41px;
          background: rgba(59,66,87,.8);
          border-radius: 8px;
          padding:0 4px;
          color: #ffffff;
          font-size: 12px;
          left: 45px;"
            :loop="true"
          >
            <swiper-item v-for="(item,ind) in lists" :key="ind">
              <p style="text-align:center;">
                <img src="@/assets/assemble/swiper.png" alt="" style="width:14px;height:14px;vertical-align:middle;">&nbsp;{{ item.mobile }}用户开卡成功，将获得{{ parseInt(item.rewardMoney) }}元现金红包
              </p>
            </swiper-item> -->
        <!-- </swiper> -->
      </div>

      <div class="content">
        <!-- <div class="content-wrap">
            <div class="content-wrap-title">
              <h4 style="font-size:18px;color:#161921;">
                【商旅出行】{{ o }}
              </h4>
              <span>更多<span class="arrow" /></span>
            </div>
            <div class="content-wrap-imgs">
              <div v-for="(item,ind) in 3" :key="ind" class="content-wrap-imgs-div">
                <p style="width:.96rem;height:.6rem;">
                  {{ item }}
                </p>
                <p style="font-size:12px;text-align:center;margin:6px 0 19px 0;">
                  已拼<countup :start-val="1" :end-val="endVal" :duration="o" class="red" :options="{'useGrouping':false}" />张卡
                </p>
                <p style="width:.95rem;height:.26rem;line-height:.26rem;background:#F4402E;color:#fff;text-align:center;border-radius:20px;">拼团</p>
              </div>
            </div>
          </div> -->
        <show-list :datalist="dataList" :title="title" :types="1" />
        <show-list :datalist="dataList2" :title="title2" :types="2" />
        <show-list :datalist="dataList3" :title="title3" :types="3" />
        <show-list :datalist="dataList4" :title="title4" :types="4" />
        <footer class="footer">
          具体优惠活动信息以银行官网为准
        </footer>
      </div>
    </div>
  </div>
  <!-- </transition> -->
</template>

<script>
import showList from './component/showList.vue'
import mixins from '@/mixins/index.js'
import { Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup } from 'vux'
import '@/utils/flex.js'
import { assembleAd, assembleDetailRadio } from '@/api/assemble-controller.js'
export default {
  name: 'Sign',
  components: {
    Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup, showList
  },
  mixins: [mixins],
  data() {
    return {
      asyncCount: 0,
      show5: false,
      endVal: 28321,
      dataList: [],
      datalist: [],
      dataList2: [],
      dataList3: [],
      dataList4: [],
      type: '',
      title2: '【商超购物】',
      title3: '【吃喝玩乐】',
      title4: '【女神专属】',
      title: '【商旅出行】',
      lists: [],
      swiperShow: true
    }
  },
  created() {
    this.setDocumentTitle('拼团办卡')
    this.getListOne(1)
    this.getListOne(2)
    this.getListOne(3)
    this.getListOne(4)
    this.init()
    window.appInvokeH5 = this.appInvokeH5
    window.callShareClient('login', '')
  },
  mounted() {

  },
  methods: {
    init() {
      const obj = {
        title: '用卡王-爱拼才会赢', // 分享标题
        desc: '拼团办卡，符合条件，秒批下卡，最高可得100元现金红包', // 分享描述
        link: window.location.href, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: 'https://ftp.runzezhihui.com/cycleImage/2019-05-29/i186172451792875520/i186172451792875520.png'
      }
      this.getWxShare(obj)
    },
    getListOne(type) {
      const obj = {}
      obj.type = type
      obj.pageSize = 1
      obj.rows = 3
      this.type = type
      assembleAd(obj).then(res => {
        if (res.code == 1) {
          switch (type) {
            case 1:this.dataList = res.resultObj.resultObj; break
            case 2:this.dataList2 = res.resultObj.resultObj; break
            case 3:this.dataList3 = res.resultObj.resultObj; break
            case 4:this.dataList4 = res.resultObj.resultObj; break
            default:
              break
          }
        }
      })
    },

    appInvokeH5(type, param) {
      switch (type) {
        case 'alreadyLogin':
          localStorage.setItem('userNo', param)
          console.log(33, param); break
        case 'shareInfo':
          this.objdesc = {
            qqimageURL: 'https://ftp.runzezhihui.com/cycleImage/2019-05-28/i185809091686899712/i185809091686899712.png', // 事先部署到服务器 qq
            wximageURL: 'https://ftp.runzezhihui.com/cycleImage/2019-05-29/i186172451792875520/i186172451792875520.png', // 事先部署到服务器 wx
            title: '用卡王-爱拼才会赢',
            subtitle: '拼团办卡，符合条件，秒批下卡，最高可得100元现金红包'
          }
          window.callShareClient('share', JSON.stringify(this.objdesc)); break
      }
    }
  }
}
</script>

<style lang="less" scoped>
@import '~vux/src/styles/reset.less';
.container{
  overflow-x: hidden;
}
.red{
  color: #F4402E;
}
.content{
    background: #FFD400;
    padding-top: 10px;
    &-wrap{
      width:3.43rem;
      margin:0 auto 16px;
      background: #fff;
      padding-top:0.16rem;
      padding-bottom:.28rem;
      border-radius: 10px;
      &-title{
        padding-right:14px;
        display: flex;
        justify-content: space-between;
      }
      &-imgs{
        width:3.43rem;
      margin:19px auto 0 auto;
      display: flex;
      justify-content: space-around;
      &-div{
        width:0.96rem;
      // border:1px solid red;
        // height:1.43rem;
      }
    }
    }
.arrow{
  display: inline-block;
  width:10px;
  height:10px;
  border-top:1px solid #161921;
  border-right:1px solid #161921;
  -webkit-transform: translate(0,0%) rotate(45deg);
  transform: translate(0,0%) rotate(45deg);
}
.footer{
  text-align: center;
  color: #333333;
  font-size: 12px;
  padding-bottom:18px;
  margin-top:19px;
}
  }

</style>
<style scoped>
slide-right-enter-active,
.slide-right-leave-active,
.slide-left-enter-active,
.slide-left-leave-active {
  will-change: transform;
  transition: all 500ms;
  position: absolute;
}
.slide-right-enter {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}
.slide-right-leave-active {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-enter {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-leave-active {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}

</style>
