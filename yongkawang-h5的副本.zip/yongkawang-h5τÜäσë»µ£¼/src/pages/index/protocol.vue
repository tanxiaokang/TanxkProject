<template>
  <div class="protocol">
    <div class="tip">
      {{ bankName }}信用卡办卡协议
    </div>
    <div>
      <div class="title">
        网上申请特别提示：
      </div>
      <div class="content">
        <div>1、申请人应完整填写申请资料及信用卡申请表并保证所填信息的真实准确； </div>
        <div>2、申请人不可重复申请中国{{ bankName }}同一信用卡产品；  </div>
        <div>3、申请人在线提交申请资料后，可以通过{{ bankName }}信用卡网站、官方微信查询信用卡审批状态；  </div>
        <div>4、中国{{ bankName }}信用卡网上申请流程中不包括副卡申请，申请人可在收到卡片后到我行营业网点申请办理副卡； </div>
        <div>5、目前我行网上申请业务仅限部分城市和地区开通，未在城市选项的城市暂未开通网上申请业务，未开通网上申请业务的城市和地区的客户如有需要，请至当地中国{{ bankName }}网点办理。  </div>
      </div>
      <div class="title">
        重要提示：
      </div>
      <div class="content">
        <div>1、申请中国{{ bankName }}信用卡的基本条件：  </div>
        <div>
          a.主卡申请人需18-65周岁（含）具有完全民事行为能力的自然人，拥有合法稳定收入且在中国人民银行的个人信用报告符合我行发卡适用条件。
        </div>
        <div>
          b.需提供有效身份证原件（包括但不限于境内居民身份证、外籍人士护照、港澳居民来往内地通行证、台湾居民来往大陆通行证等）。
        </div>
        <div>2、持卡人所持信用卡具有电子支付功能。电子支付包含网银支付、协议支付、手机支付、快捷支付、银联在线支付等支付类型。持卡人通过物理网点、电子渠道或在首笔交易发生前开通电子支付功能的，银行将依照监管要求验证持卡人身份、卡片信息等，持卡人同意并授权银行为交易安全之目的采取以上行为。 </div>
        <div>3、为向您提供更加优质的服务，您知悉并同意在卡片有效期内我行向您不定期发送服务通知及业务推荐短信息，如您需要取消接收业务推荐短信息，可随时联系我行进行变更。  </div>
        <div>4、贷记卡透支按月计收复利，透支利率根据持卡人资质、用卡情况、交易类型等不同由发卡机构核准或调整，日利率区间为万分之三点五至万分之五（年利率区间为12.7750%-18.2500%），并根据中国人民银行的此项利率变动而调整。贷记卡账户内的存款不计付利息。 </div>
        <div>5、请您妥善保管您的个人信息及信用卡卡面信息，请勿将信用卡交易密码、动态密码等信息透露给他人，任何向您索要密码的行为均属诈骗。  </div>
        <div>6、请您按时足额还款，若您未偿还全部当期应还款额，将不再享受免息还款期待遇，应支付透支利息；若您未全部偿还最低还款额，将产生利息、违约金，且我行将按照相关规定报送逾期信息至中国人民银行，对您的个人信用会造成一定的影响。</div>
        <div>7、请您认真阅读《中国{{ bankName }}信用卡章程》和您所申请信用卡相关《领用合约》，在理解和知悉相关条款后在“声明及签署”栏位亲笔签名。</div>
      </div>
      <div class="title">
        警示：
      </div>
      <div class="content">
        <div>1、信用卡恶意透支属于违法行为，切勿恶意透支信用卡，否则将被以信用卡诈骗罪起诉并受到《中华人民共和国刑法》制裁。</div>
        <div>2、根据《中华人民共和国刑法》第196条规定：使用伪造、作废的信用卡，或者冒用他人信用卡的，或者使用以虚假身份证明骗领的信用卡的，最高可处十年以上有期徒刑或无期徒刑，并处五万元以上五十万元以下罚金或没收财产。</div>
        <div>3、切勿将个人信息提供给中介机构办理信用卡，以防上当受骗。</div>
      </div>
      <div class="title">
        本人声明申请表所填各项内容均属事实，同意银行向任何有关方面调查。
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Protocol',
  data() {
    return {
      bankName: undefined
    }
  },
  created() {
    this.bankName = this.$route.params.id
    this.setDocumentTitle('办卡协议')
  }
}
</script>

<style lang="less">
     .protocol{
         .tip{
             font-family: PingFangSC-Semibold;
             font-size: 1.2rem;
             color: #333333;
             text-align: center;
             padding-bottom: 1rem;
             padding-top: 1rem;
         }
         padding: 1rem;
         .title{
             font-weight: bold;
             font-size: 0.9125rem;
             margin: 1rem 0;
         }
         .content{
           box-sizing: border-box;
             padding: 0 1rem;
             font-size: 0.835rem;
             color:#666666;
             letter-spacing: 2px;
             line-height: 1.4rem;
         }
     }
</style>
