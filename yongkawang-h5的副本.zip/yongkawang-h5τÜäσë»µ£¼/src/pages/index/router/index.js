import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// 路由懒加载，过几天再优化

export default new VueRouter({
  routes: [
    // {
    //   path: '/',
    //   redirect: '/applyBank'
    // },
    // 申卡模块
    {
      path: '/applyBank',
      name: 'Index',
      component: resolve => require(['@/pages/index/applyBank'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/applyCard',
      name: 'Index',
      component: resolve => require(['@/pages/index/applyCard'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/protocol/:id',
      name: 'protocol',
      component: resolve => require(['@/pages/index/protocol'], resolve),
      meta: {
        keepAlive: false
      }
    },
    /**
     * 提现模块
     */
    {
      path: '/bindCard',
      name: 'bindCard',
      component: resolve => require(['@/pages/index/bindCard'], resolve),
      meta: {
        keepAlive: false
      }
    },

    /**
     * 活动模块
     */
    {
      path: '/activei-share',
      name: 'activei-share',
      component: resolve => require(['@/pages/index/activei-share'], resolve),
      meta: {
        keepAlive: true
      }
    },
    {
      path: '/activei',
      name: 'activei',
      component: resolve => require(['@/pages/index/activei'], resolve),
      meta: {
        keepAlive: false
      }
    },
    // {
    //   path: '/activeg',
    //   name: 'activeg',
    //   component: resolve => require(['@/pages/index/activeg'], resolve),
    //   meta: {
    //     keepAlive: false
    //   }
    // },
    // {
    //   path: '/activeg-share',
    //   name: 'activeg-share',
    //   component: resolve => require(['@/pages/index/activeg-share'], resolve),
    //   meta: {
    //     keepAlive: true
    //   }
    // },
    {
      // 关于我们
      path: '/about',
      name: 'about',
      component: resolve => require(['@/pages/index/about'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 协议
      path: '/userProtocol',
      name: 'userProtocol',
      component: resolve => require(['@/pages/index/userProtocol'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 服务于协议
      path: '/serviceProtocol',
      name: 'serviceProtocol',
      component: resolve => require(['@/pages/index/serviceProtocol'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 公司介绍
      path: '/companyDesc',
      name: 'companyDesc',
      component: resolve => require(['@/pages/index/companyDesc'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 	信息授权服务协议
      path: '/mesProtocol',
      name: 'mesProtocol',
      component: resolve => require(['@/pages/index/mesProtocol'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 	高权益白金卡
      path: '/highpt',
      name: 'highpt',
      component: resolve => require(['@/pages/index/highpt.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 	测试微信二次分享页面
      path: '/hnew',
      name: 'hnew',
      component: resolve => require(['@/pages/index/highpt-new.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 	第一张信用卡
      path: '/firstcard',
      name: 'firstcard',
      component: resolve => require(['@/pages/index/firstcard.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 	61儿童节
      path: '/sixone',
      name: 'sixone',
      component: resolve => require(['@/pages/index/sixone.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 	年度热卡
      path: '/year',
      name: 'year',
      component: resolve => require(['@/pages/index/year.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/demo',
      name: 'demo',
      component: resolve => require(['@/pages/index/demo.vue'], resolve),
      meta: {
        keepAlive: false
      }
    }, {
      path: '/luckdraw',
      name: 'luckdraw',
      component: resolve => require(['@/pages/index/luckdraw.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/signin',
      name: 'signin',
      component: resolve => require(['@/pages/index/signin.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    // 拼团办卡
    {
      path: '/Assemble',
      name: 'Assemble',
      component: resolve => require(['@/pages/index/Assemble.vue'], resolve),
      meta: {
        keepAlive: false
      }
    }, {
      // 上门办理地址
      path: '/applyCreditcard',
      name: 'applyCreditcard',
      component: resolve => require(['@/pages/index/applyCreditcard.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/drxySignProtocol',
      name: 'drxySignProtocol',
      component: resolve => require(['@/pages/index/drxySignProtocol.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    // 卡详情
    {
      path: '/cardykwDetail',
      name: 'cardykwDetail',
      component: resolve => require(['@/pages/index/cardDetail.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    // 卡列表
    {
      path: '/cardList',
      name: 'cardList',
      component: resolve => require(['@/pages/index/cardList.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 正在拼团
      path: '/AssembleLists',
      name: 'AssembleLists',
      component: resolve => require(['@/pages/index/AssembleLists.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      // 拼团活动规则
      path: '/AssembleRules',
      name: 'AssembleRules',
      component: resolve => require(['@/pages/index/AssembleRules.vue'], resolve),
      meta: {
        keepAlive: false
      }
    },
    {
      path: '/result',
      name: 'result',
      component: resolve => require(['@/pages/index/result.vue'], resolve),
      meta: {
        keepAlive: false
      }
    }
  ]
})
