<template lang="pug">
  div.apply-card(style="overflow: hidden;background: #ffffff;height:100vh;font-size:16px;")
    //-表单 --------------------------------------------------------------
    div.bottom-wrap(
      ref='bottomWrap'
      style="overflow-y:scroll;width:100%;overflow-x: hidden;overflow-y: scroll;position: absolute;")
      div
        div.certContent
            div(style="width:80%")
              x-input(
                label-width='90'
                title="姓&nbsp;&nbsp;&nbsp;&nbsp;名"
                v-model="userName"
                is-type='china-name'
                :show-clear='false'
                placeholder="请输入中文姓名")
            div(style='width:80%;')
              x-input(
                type='number'
                label-width='90'
                title="身份证"
                is-type='china-idcard'
                :show-clear='false'
                v-model="idCard"
                :max='18'
                placeholder="请输入身份证号")
        div.contacts
            div(style="width:80%")
                x-input(
                  title="手机号"
                   v-model="applyMobile"
                   label-width='90'
                   type='tel'
                   is-type="china-mobile"
                   :max='13'
                   mask='999 9999 9999'
                   :show-clear='false'
                   placeholder="请输入手机号")
            div.vertCode
                div(
                  style="width:80%")
                    x-input(
                      title="验证码"
                      v-model="code"
                      type='tel' :max='6'
                      label-width='90'
                      :show-clear='false'
                      placeholder="请输入验证码"
                      )
                x-button(
                  @click.native="getCode" plain mini
                  :disabled="disabled"
                  :style="{'padding':'0 20px 0 0','border':'none'}")
                  countdown(
                    v-show="!show"
                    v-model="time"
                    :start="start" @on-finish="finish")
                  div(
                    v-show="show"
                    :style="{'color':'#161921','font-size':'12px','font-family':'PingFang-SC-Medium','background':'#FFDA33','border-radius':'20px','padding':'4px','width':'75px'}"
                  ) 获取验证码
            div(
              style="padding:15px 0 13px 20px;")
              div(
              style="display:flex; align-items: center;")
                check-icon(:value.sync="checkIcon")
                div
                    span(
                      style="color: #9AA1B6;font-size:14px;"
                    ) &nbsp;阅读并同意
                    span(@click="goProtocol" style="color:#FFDA33 ;font-size:14px;"
                  ) 《用户隐私协议》
            div
              div(
                style='width:90%;margin:24px auto 0;border-radius:20px;text-align:center;padding-top:9px;padding-bottom:9px;color:#9AA1B6;background:rgba(255, 218, 51,.3);' v-if='!this.applyMobile || !this.userName || !this.code || !this.idCard || !this.checkIcon'
              ) 申请
              div(
                style='width:90%;margin:24px auto 0;border-radius:20px;text-align:center;padding-top:9px;padding-bottom:9px;color:#161921;background:#FFDA33;' v-else
                @click='nextStep'
              ) 申请

            //- div(style='width:100%;text-align:center;position:fixed;bottom:10px;' id='footer')
            //-   img(src='@/assets/apply-footer.png' style='width:90%;vertical-align:middle;')
</template>

<script>
// import '@/utils/flexApply'
import { getUrlQueryObj } from '@/utils/index.js'
import { agreementUrl, applyCard, applysendSms, apply, onlineUserInfo, applyAssemble } from '@/api'
import { start } from '@/api/assemble-controller.js'
import { XAddress, XInput, Countdown, XButton, XDialog, Checklist, CheckIcon, TransferDomDirective as TransferDom } from 'vux'
export default {
  name: 'ApplyCard',
  directives: {
    TransferDom
  },
  components: {
    XInput,
    Countdown,
    XButton,
    XDialog,
    Checklist,
    CheckIcon,
    XAddress
  },
  data() {
    return {
      userName: '',
      idCard: '',
      applyMobile: '',
      mobile: undefined,
      code: '',
      time: 59,
      show: true,
      start: false,
      disabled: false,
      showModal: false,
      checkIcon: false,
      obj: {},
      urlQuery: {},
      local: {
        applyNo: '',
        url: ''
      }
    }
  },
  computed: {},
  created() {
    this.setDocumentTitle('申请信用卡')
    this.$vux.loading.hide()
    this.getDatas()
    this.obj = getUrlQueryObj()
    console.log(90, this.obj)
    // console.log(78, decodeURI(this.obj.netApplyAddress))
    console.log(79, decodeURIComponent(this.obj.netApplyAddress))
  },
  methods: {
    initPage() {
      this.fetchData()
    },
    fetchData() {
      const params = {}
      params.bankId = this.bankId
      agreementUrl(params).then(res => {
        this.bankCode = res.resultObj.bankCode
        this.bankId = res.resultObj.bankId
        this.bankName = res.resultObj.bankName
        this.creditAgreement = res.resultObj.creditAgreement
      })
    },
    goProtocol() {
      this.$router.push({
        path: '/serviceProtocol'
      })
    },
    getDatas() {
      const obj = {}
      obj.userNo = localStorage.getItem('userNo')
      obj.type = 1
      onlineUserInfo(obj).then(res => {
        this.urlQuery = res.resultObj
        this.mobile = this.urlQuery.applyMobile || ''
        this.applyMobile = this.urlQuery.applyMobile || ''
        this.idCard = this.urlQuery.idCard || ''
        this.userName = this.urlQuery.realName || ''
      })
    },
    // 倒计时后处理
    finish(index) {
      this.start = false
      this.show = true
      this.disabled = false
      this.time = 29
    },
    getCode() {
      if (!this.applyMobile) {
        this.$vux.toast.show({
          type: 'cancel',
          text: '请输入手机号'
        })
        return
      }
      const params = {}
      params.mobile = (this.applyMobile).replace(/\s*/g, '')
      params.type = 1
      applysendSms(params).then(res => {
        this.start = true
        this.show = false
        this.disabled = true
        this.$vux.toast.show({
          type: 'success',
          text: res.message
        })
      })
    },
    nextStep() {
      if (!this.userName) {
        this.showToast('', 'text', '姓名不能为空')
        return
      }
      if (!this.idCard) {
        this.showToast('', 'text', '身份证号不能为空')
        return
      }
      if (!this.applyMobile) {
        this.showToast('', 'text', '请输入手机号')
        return
      }
      if (!this.code) {
        this.showToast('', 'text', '请输入验证码')
        return
      }
      if (!this.checkIcon) {
        this.showToast('', 'text', '请同意协议')
        return
      }

      // 如果有cid编码
      const arg = {}
      arg.mobile = (this.applyMobile).replace(/\s*/g, '')
      arg.name = this.userName
      arg.idCard = this.idCard
      arg.applySource = this.obj.applySource// 前面带的  区分ykw 51 好贷
      arg.vcode = this.code
      arg.cid = this.obj.cid// 卡编码
      arg.channel = this.obj.channel // 渠道
      // arg.applyNo = this.obj.applyNo || '' // 申请编码
      applyAssemble(arg).then(data => {
        // 得到applyNo
        if (data.code === 1) {
          this.local.applyNo = data.resultObj.applyNo
          this.local.url = data.resultObj.url
          if (this.obj.assembles && this.obj.assembles == 1) {
            // 支持拼团
            this.defaultAssemble()
          } else {
            this.jumpUrlorNet(data)
          }
        } else {
          this.$vux.toast.show({
            type: 'cancel',
            text: data.message
          })
        }
      })
    },
    defaultAssemble() {
      // 调 拼团接口
      const params = {}
      params.applyNo = this.local.applyNo
      params.assembleNo = this.obj.assembleNo
      params.channel = this.obj.channel
      params.creditNo = this.obj.creditNo // 卡种编号
      params.flag = this.obj.flag
      params.mobile = (this.applyMobile).replace(/\s*/g, '')
      params.rewardMoney = this.obj.rewardMoney // 返佣金额
      params.type = 1 // 网申
      start(params).then(res => {
        if (res.code == 1) {
          this.jumpUrlorNet(res)
        }
      })
    },
    jumpUrlorNet(res) {
      if (!this.local.url && !this.obj.netApplyAddress) {
        this.$vux.toast.show({
          type: 'cancel',
          text: '系统异常,请联系客服人员'
        })
      } else if (this.local.url) {
        this.$vux.toast.show({
          type: 'cancel',
          text: res.message
        })
        setTimeout(() => {
          location.href = this.local.url
        }, 1500)
      } else if (this.obj.netApplyAddress) {
        this.$vux.toast.show({
          type: 'cancel',
          text: res.message
        })
        setTimeout(() => {
          location.href = decodeURIComponent(this.obj.netApplyAddress)
        }, 1500)
      }
    }
  }
}
</script>

<style lang="less" scoped>
    .weui-cell:before{
        display: none!important;
    }
    .weui-cells:after{
        display: none!important;
    }
    .weui-cells:before{
        display: none!important;
    }
    .apply-card{
        .weui-input{
          font-size: 16px!important;
          font-family: PingFangSC-Regular, sans-serif;
          font-weight: 500;
        }
        .weui-cell__bd{
          width:60%!important;
        }
        .weui-cells__title{
            font-family: PingFangSC-Medium;
            font-size: 1.125rem;
            color: #333333;
        }
        .modalTrans{
            .weui-cell__bd{
                color: #333333!important;
                text-align: left!important;
                font-size: 0.875rem!important;
            }
        }
        .block-title{
            font-family: PingFangSC-Semibold;
            font-size: 1.25rem;
            color: #333333;
            padding: 1.875rem 0 1rem 0;
            margin:0 1.2rem ;
            border-bottom: 1px solid #f3f3f3;
            font-weight:700
        }
        .contacts{
            .vertCode{
                display: flex;
                justify-content: space-between;
            }
        }
    }
</style>
<style scoped>
.apply-card >>> .weui-icon-circle{
  font-size:14px;
}
.apply-card >>> .weui-cell{
  padding-left:20px;
  padding-top: 15px;
  padding-bottom: 13px;
}
.apply-card >>> .weui-btn{
  line-height: inherit;
}
.apply-card >>> .weui-label{
  font-size:16px;
  color:#3B4257!important;

}
.apply-card>>> .weui-icon-success{
  font-size:14px;
  color:#FFDA33;
}
.apply-card >>> .weui-icon-circle:before {
    content: "\EA01";
    color: #FFDA33;
}
.apply-card >>> .vux-check-icon > .weui-icon-success:before, .vux-check-icon > .weui-icon-success-circle:before{
  color: #FFDA33!important;
}
.apply-card >>> .weui-input::placeholder{
  color:#9AA1B6;
  /* color:red/; */
}
input::-webkit-input-placeholder { /* WebKit browsers */
    color:   #9AA1B6;
}
input:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
    color:   #9AA1B6;
}
input::-moz-placeholder { /* Mozilla Firefox 19+ */
    color:   #9AA1B6;
}
input:-ms-input-placeholder { /* Internet Explorer 10+ */
    color:   #9AA1B6;
}
 /* button[data-v-fd3c7d66] span[data-v-fd3c7d66]{
   display: inline-block;
    background: rgba(255, 218, 51,.3);
    width: 75px;
    padding: 4px;
    border-radius: 20px;
    color: #161921;
} */
.apply-card >>> .vux-input-icon.weui-icon-warn:before, .vux-input-icon.weui-icon-success:before{
  display: none!important;
}
</style>

