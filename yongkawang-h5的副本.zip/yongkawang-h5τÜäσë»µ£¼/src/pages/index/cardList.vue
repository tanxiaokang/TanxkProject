<template class="container">
  <transition name="slide-left">
    <div class="detail">
      <img src="@/assets/assemble/top.png" alt="" style="width:53px;height:78px;">
      <div v-for="(item,ind) in lists" :key="ind" class="detail-card">
        <div class="detail-card-title">
          <h4>【{{ item.creditName }}】</h4>
          <span v-if="ind<=2" class="tag">NO.{{ ind+1 }}</span>
        </div>
        <div class="detail-card-content">
          <div class="left">
            <img :src="item.smallUrl" alt="" style="width:1.28rem;height:.8rem;">
            <span class="already">已拼265张</span>
          </div>
          <div v-for="(content,ids) in item.exclusiveInfo.split('\n')" :key="ids" class="right">
            <p>.{{ content }}</p>
          </div>
        </div>
        <div class="detail-card-button" @click="handleStartassemble(item.creditNo)">
          拼团
        </div>
      </div>
      <footer class="footer">
        具体优惠活动信息以银行官网为准
        <img
          src="@/assets/assemble/bottom.png"
          alt=""
          style="width:51px;height:46px;position: absolute;bottom: 0;right: 0"
        >
      </footer>
    </div>
  </transition>
</template>

<script>
import showList from './component/showList.vue'
import { Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup } from 'vux'
import '@/utils/flex.js'
import { assembleAd } from '@/api/assemble-controller.js'
export default {
  name: 'Sign',
  components: {
    Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup, showList
  },
  data() {
    return {
      lists: [],
      title: '',
      exclusiveInfos: []
    }
  },
  created() {
    const title = this.getTitle()
    this.setDocumentTitle(title)
    this.getLists()
  },
  mounted() {

  },
  methods: {
    // 根据参数判断页面数据展示
    getTitle() {
      let str = ''
      const _type = Number(this.$route.query.type)
      switch (_type) {
        case 1:str = '【商旅出行】'; break
        case 2:str = '【商超购物】'; break
        case 3:str = '【吃喝玩乐】'; break
        case 4:str = '【女神专属】'; break
        default:break
      }
      return str
    },
    getLists() {
      const type = Number(this.$route.query.type)
      // if(title='')
      const obj = {}
      obj.type = type
      obj.pageSize = 1
      obj.rows = 6
      assembleAd(obj).then(res => {
        if (res.code == 1) {
          this.lists = res.resultObj.resultObj
        } else {
          this.$vux.toast.show({
            type: 'cancel',
            text: res.message
          })
        }
      })
    },
    handleStartassemble(creditNo) {
      this.$router.push({
        path: './cardykwDetail',
        query: {
          creditNo: creditNo
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
@import '~vux/src/styles/reset.less';
*{
    box-sizing: border-box;
}
.detail{
    width:3.75rem;
    background: #FFD400;
    min-height: 100vh;
    // padding:.58rem 0 0 0;
    &-card{
         position: relative;
        width:3.43rem;
         padding: 16px 0 20px;
        margin:0 auto 16px;
        background: #fff;
        border-radius: 10px;
        &-title{
            h4{
                color:#161921;
                font-size: 18px;
            }
            .tag{
                position: absolute;
                display: inline-block;
                width:40px;
                height: 29px;
                line-height: 29px;
                text-align: center;
                background: #292929;
                color: #FFD400;
                right:16px;
                font-size: 14px;
                top:0;
            }

        }
        &-content{
            padding:0 16px;
            margin-top: 17px;
            display: flex;
            align-items: center;
            .left{
                position: relative;
                .already{
                    position: absolute;
                    color: #fff;
                    bottom: 0;
                    display: inline-block;
                    width:.83rem;
                    text-indent: 7px;
                    font-size: 12px;
                    background: linear-gradient(to right,#F4402E,#fff);
                    background: -webkit-linear-gradient(to right,#F4402E,#fff);
                    background: -o-linear-gradient(to right,#F4402E,#fff);
                    background: -moz-linear-gradient(to right,#F4402E,#fff);
                }
            }
            .right{
                margin-left: .13rem;
                p{
                    color: #3B4257;
                    font-size: .14rem;
                }
            }
        }
        &-button{
            width:1.8rem;
            height: .4rem;
            background: #F4402E;
            color: #fff;
            font-size: .16rem;
            text-align: center;
            border-radius: 40px;
            line-height: .4rem;
            margin: 14px auto 0;
        }
    }
}
.footer{
  text-align: center;
  color: #333333;
  font-size: 12px;
  padding-bottom:18px;
  margin-top:19px;
  position: relative;
}
</style>
<style scoped>
slide-right-enter-active,
.slide-right-leave-active,
.slide-left-enter-active,
.slide-left-leave-active {
  will-change: transform;
  transition: all 500ms;
  position: absolute;
}
.slide-right-enter {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}
.slide-right-leave-active {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-enter {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-leave-active {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}

</style>
