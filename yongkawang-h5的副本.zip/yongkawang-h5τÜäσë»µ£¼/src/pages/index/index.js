
import Vue from 'vue'
import FastClick from 'fastclick'
import Vuex from 'vuex'
import App from './index.vue'
import router from './router'
import 'babel-polyfill'
import VConsole from 'vconsole' // console 日志
import promise from 'es6-promise'
import setDocumentTitle from '@/utils/setDocumentTitle'
import request from '@/utils/request'
import '@/style/public.less'
import '@/utils/adaptor.js' // 与app通信入口
import '@/utils/flex.js'
import uweb from 'vue-uweb' // 引入友盟插件
// Vue.use(uweb, '1277729904')
Vue.use(uweb, {
  siteId: '1277729904',
  debug: false,
  autoPageview: true,
  src: 'https://s23.cnzz.com/z_stat.php?id=1277729904&web_id=1277729904'
})
/**
 * <script type="text/javascript" src="https://s23.cnzz.com/z_stat.php?id=1277729904&web_id=1277729904"></script>
 */
Vue.use(Vuex)

promise.polyfill()

import { LoadingPlugin } from 'vux'
import { ToastPlugin } from 'vux'
Vue.use(ToastPlugin)
Vue.use(LoadingPlugin)

const state = {
  isShowTabbar: true
}
new VConsole()
/* 公共toast*/

Vue.prototype.showToast = function(showPositionValue = 'middle', type, time, text, width = '10em') {
  this.$vux.toast.show({
    text: text,
    type: type,
    time: time,
    width: width,
    position: showPositionValue,
    showBackArrow: true
  })
}

FastClick.attach(document.body)

Vue.config.productionTip = false
Vue.prototype.request = request
Vue.prototype.setDocumentTitle = setDocumentTitle

const store = new Vuex.Store({
  state
})

/* 控制底部显示*/
//
router.afterEach((to, from, next) => {
  window.scrollTo(0, 0)
})
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app-box')
