
<template lang='pug'>
  div.group-wrap.page-container
    div.top
      img(
        :src="inviteBg"
        style='width:3.75rem'
      )
    div.content
      //-app可见
      div(style='position:relative')
        div(style='width:3.75rem;height:1rem;')
          img.full-img(src='@/assets/bg-invite-line.png' style='widht:100%')
        div.block.c-top-wrap
          div.c-top-left
            div.money
              span|¥&nbsp
              span(style='font-size:24px')|{{myMoney}}
              span|&nbsp元现金
          div.c-top-right
            div.btn-color(
              @click='extract'
              style="width:.8rem;height:.3rem;line-height:.3rem;border-radius:.08rem;font-size:16px")|提现

      //- 全部可见
      div.block(style="padding:20px 17px;box-sizing:border-box;font-size:14px;line-height:26px")
        div.title-c(style="font-size:18px;")|活动规则
        div.title-c(v-for="item in active") {{item.title}}
          div(v-if='item.children.length!=0' v-for='i in item.children') {{i}}
      //- 按钮 app可见
      div
        div.btn-color(
          @click='share'
          style="width:3.35rem;height:40px;font-size:17px;line-height:40px;margin:0 auto;border-radius:20px")|立即邀请
    active-dialog(
      @closeDialog='closeDialog'
      @submitMoney='submitMoney'
      :dialogFlag='dialogFlag'
      :editMoney='myMoney'
      :dialogType='moneyDialogFlag')
</template>

<script>
import '@/utils/flex.js'
import axios from 'axios'
import { XInput, Countdown } from 'vux'
import activeDialog from '@/components/active-invite-dialog.vue'
import activeMixin from '@/mixins/active-mixin'
import { checkActivity, getActiveInfo, getUserBackList, withdraw, inviteDetail } from '@/api'

export default {
  name: 'App',
  components: {
    XInput,
    Countdown,
    activeDialog
  },
  mixins: [activeMixin],
  data: function() {
    return {
      active: [
        {
          title: ' 1.邀请人奖励机制：',
          children: [
            '(1)被邀请人数为1<X≤5，开卡激活成功，邀请人奖励25元；',
            '(2)被邀请人数为5<X≤10，开卡激活成功，邀请人奖励40元；',
            '(3)被邀请人数为10<X≤20，开卡激活成功，邀请人奖励50元；',
            '(4)被邀请人数为20<X≤50，开卡激活成功，邀请人奖励80元；',
            '(5)被邀请人数为X>50，开卡激活成功，邀请人奖励100元； '
          ]
        },
        { title: '2.被邀请人申卡激活成功后，可获得25元红包奖励；', children: [] },
        { title: '3.红包奖励发放后，将发放到用户的账户中，可进行绑卡提现；', children: [] },
        { title: '4.邀请人奖励上限为100元； ', children: [] },
        { title: '5.被邀请人在分享后的页面快捷登录成功且申卡并激活成功视为邀请成功； ', children: [] },
        { title: '6.同一用户邀请开卡得奖励和拼单办卡赢奖励两个活动只能参与一个;  ', children: [] },
        { title: '7.本活动规则最终解释权为用卡王所有。', children: [] }
      ],
      descArr: [
        '最全信用卡卡库',
        '白金卡90%通过率',
        '最新信用卡优惠活动',
        '智能提额工具'
      ],
      inviteM: undefined,
      selfM: undefined,
      path: '',
      // 验证码
      time: 45,
      start: false,
      inviteBg: require('@/assets/bg-invite.png'),
      trueName: '',
      idCard: ''
    }
  },
  computed: {},
  created() {
    const _urlQueryObj = this.$route.query
    console.log(56, _urlQueryObj)
    this.selfM = _urlQueryObj.selfM
    this.userNo = _urlQueryObj.un
    this.token = _urlQueryObj.token
    this.myMoney = 100
    this.init()
    this.genPath()
  },
  methods: {
    init() {
      // 获取用户可提现金额
      getActiveInfo(this.userNo).then(res => {
        this.myMoney = res.resultObj
      })
      // 获取用户绑卡列表, 更改绑卡状态
      getUserBackList(this.selfM).then(res => {
        console.log(res)
        if (res.errorCode == '0000') {
          this.bindStatus = 1
          this.bankCardNo = res.data[0].bankCard
          this.trueName = res.data[0].trueName
          this.idCard = res.data[0].idCard
        } else {
          // 未绑定银行卡
          this.bindStatus = 0
        }
      })
    },
    genPath() {
      const _path = location.href.split('#/')[0]
      this.path = _path
      console.log('genPath', this.path)
    },
    share() {
      this.$vux.toast.show('敬请期待~')
      // 查询邀请资格

      // axios('') 用axios 直接请求后端接口, 参数

      // 分享前查询活动资格
      // const params = {}
      // params.mobile = this.selfM
      // params.type = 1
      // console.log(11, params)
      // checkActivity(params).then(res => {
      //   if (res.code == 1) {
      //     this.commitshare()
      //   } else {
      //     console.log(res)
      //     this.$vux.toast.show({
      //       type: 'cancel',
      //       text: res.message,
      //       width: '14em'
      //     })
      //   }
      // })
    },
    commitshare() {
      try {
        const params = {}
        params.url = this.path + '#/activei-share?inviteM=' + this.selfM
        params.imageURL = this.path + this.inviteBg
        params.subtitle = '用卡王App邀请开卡月入十万'
        params.title = '邀请开卡得奖励'
        console.log(params)
        this.h5toNative('share', JSON.stringify(params))
      } catch (error) {
        this.$vux.toast.show({
          text: '页面参数有误',
          type: 'warn'
        })
      }
    },
    submitMoney(money) {
      const params = {}
      params.amount = money
      params.accountNo = this.userNo
      params.bankCard = this.bankCardNo
      params.trueName = this.trueName
      params.idCard = this.idCard
      withdraw(params).then(res => {
        this.dialogFlag = false
        this.$vux.toast.show({
          type: res.code == 1 ? 'success' : 'cancel',
          text: res.message
        })
      })
    },
    extract() {
      this.$vux.toast.show('敬请期待~')
    }
  }
}
</script>

<style lang="less">
  @import '~vux/src/styles/reset.less';
  @media screen and (min-width: 520px) {

  }
  .title-c{
    color:#B5B3CE;
    div{
      color:#B5B3CE
    }
  }
  .page-container{
    width: 3.75rem;
    margin: 0 auto;
  }
  .group-wrap{
    background:#2A2967;
  }
  .content{
    box-sizing: border-box;
    position: relative;
    padding-bottom: 20px;
    width: 100%;
    .block{
      width: 3.45rem;
      border-radius: 10px;
      margin: 0 auto;
      background:transparent;
      margin-bottom:15px;
    }
    .c-top-wrap{
      position: absolute;
      top: .17rem;
      left: .24rem;
      width: 3.25rem;
      height: .66rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .c-top-left{
        width: 2.1rem;
        .money{
          font-size:16px;
          color:#FF005E;
          margin-left:.15rem;
        }
      }
      .c-top-right{
        width: 1.15rem;
        height: .66rem;
        display: flex;
        justify-content: center;
        align-items: center;
        border-left: 1px dashed #64309B;
      }
    }
  }
  .btn-color{
    background-image: linear-gradient(left,#C046F0,#CE23C5);
    background: -webkit-linear-gradient(left,#CE23C5,#CE23C5);
    color:#FFFFFF;
    display: flex;
    justify-content: center;
  }
  .dest-top{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    >div{
      width: 50%;
    }
  }
  .chameleon{
    position: relative;
    margin: 5px 0 5px;
    img{
      position: absolute;
      top: 4px;
      left: .14rem;
      width: 11px;
      height: 11px;
    }
    span{
    margin-left:.3rem;
    background-image: linear-gradient(to right, #C49A54, #9D692C);
    background: -webkit-linear-gradient(to right, #C49A54, #9D692C);
    background-clip: text;
    -webkit-background-clip: text;
    color: transparent;
    }
  }
</style>
