import wx from 'weixin-js-sdk'
import { getWXConfigSignature } from '@/api/index.js'
export default {
  data() {
    return {
      mixinsLocal: {
        desc: ''
      }
    }
  },
  methods: {
    init() {
      wx.checkJsApi({
        jsApiList: ['updateAppMessageShareData', 'updateTimelineShareData'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
        success: function(res) {

        }
      })
      const params = {}
      params.url = (window.location.href)
      getWXConfigSignature(params).then(res => {
        if (res.code == 1) {
          this.local.mes = res.resultObj
          this.$vux.loading.hide()
          wx.config({
            debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: this.local.mes.appId, // 必填，公众号的唯一标识
            timestamp: this.local.mes.timestamp, // 必填，生成签名的时间戳
            nonceStr: this.local.mes.nonceStr, // 必填，生成签名的随机串
            signature: this.local.mes.signature, // 必填，签名
            jsApiList: ['updateAppMessageShareData', 'updateTimelineShareData'] // 必填，需要使用的JS接口列表
          })
          wx.ready(function() { // 需在用户可能点击分享按钮前就先调用
            wx.updateAppMessageShareData({
              // 分享给朋友
              title: '注册得888金币(可兑现金)', // 分享标题
              desc: this.mixinsLocal.desc, // 分享描述
              link: window.location.href, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
              imgUrl: 'https://ftp.runzezhihui.com/cycleImage/2019-05-29/i186172451792875520/i186172451792875520.png', // 分享图标
              success: function() {
                // 设置成功
              }
            })
            wx.updateTimelineShareData({
              // 分享到朋友圈
              title: '注册得888金币(可兑现金)', // 分享标题
              desc: this.mixinsLocal.desc, // 分享描述
              link: window.location.href, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
              imgUrl: 'https://ftp.runzezhihui.com/cycleImage/2019-05-29/i186172451792875520/i186172451792875520.png', // 分享图标
              success: function() {
                // 设置成功
              }
            })
          })
        }
      })
    }
  },
  created() {
    const url = location.href

    console.log(88, url.substr(url.indexOf('#') + 2))
    const path = url.substring(url.indexOf('#') + 2)
    switch (path) {
      case 'highpt?form=ykw': this.mixinsLocal.desc = '高权益高额度白金卡限时申请，高通过率，最快当天拿卡'; break
      case 'year?form=ykw': this.mixinsLocal.desc = '年度热门信用卡，折扣超多速来申请，开卡礼、刷卡礼各种优惠来袭~'; break
      case 'sixone?form=ykw': this.mixinsLocal.desc = '浓情端午·粽享安康 快来申请一张超赞的信用卡'; break
      case 'firstcard?form=ykw': this.mixinsLocal.desc = '办卡有礼、快捷办卡大额信用卡，吃喝玩乐一卡搞定'; break
      default:break
    }
    this.init()
  }
}
