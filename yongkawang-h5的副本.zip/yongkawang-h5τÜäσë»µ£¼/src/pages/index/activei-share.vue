
<template lang='pug'>
  div.group-wrap
    div.top
      img(
        src="@/assets/bg-invite.png"
        style='width:3.75rem'
      )
    div.content
      //- 被分享人可见
      div.block.dest-top(
        style='font-size:14px;background:#3F3E90')
          div.chameleon(v-for='item in descArr')
            img(src="@/assets/icon-star.png")
            span {{item}}
      //- 全部可见
      div.block(style="padding:20px 17px;box-sizing:border-box;font-size:14px;line-height:26px")
        div.title-c(style="font-size:18px;")|活动规则
        div.title-c(v-for="item in active") {{item.title}}
          div(v-if='item.children.length!=0' v-for='i in item.children') {{i}}

      //- 被分享人可见--注册前可见
      div(
        v-if='!login'
        style="width:2.95rem;margin:30px auto")
        div.active-input-wrap(style="margin-bottom:28px")
          x-input(title="" :max="13" placeholder="请输入手机号" type='tel' v-model='mobile')
        div.active-input-wrap(style="margin-bottom:18px")
          x-input(title=""  :max="6" placeholder="请输入验证码" type='tel' v-model='vcode' :show-clear="false")
            div(slot="right")
              span.code-span(@click='getCode' v-if='!start') 获取验证码
              span.code-span.disabled(v-if='start')
                countdown( v-model="time" :start="start" @on-finish="finish")
                |秒
        div(style="color:#ffffff;font-size:15px;font-weight:300;display:flex;align-items: center;justify-content: flex-start;")
          div(
            @click='handleAgree'
            style='width:21px;height:21px;margin-right:10px;')
            img.full-img(
              v-if='!protocolFlag'
              src='@/assets/55.png')
            img.full-img(
              v-else
              src='@/assets/56.png')
          div 我已阅读并同意《&nbsp
            span(
              @click='goPage'
              style='text-decoration: underline;') 用户使用协议
            |&nbsp》

      //- 被分享人注册前可见
      div.btn-color(
        @click='submit'
        v-if='!login'
        style="width:3.35rem;height:40px;font-size:17px;line-height:40px;margin:0 auto;border-radius:20px")|立即参与活动

      //- 被分享人注册后可见
      div.btn-color(
        v-else
        style="width:3.35rem;height:40px;font-size:17px;line-height:40px;margin:0 auto;border-radius:20px")|下载用卡王App拿奖励
</template>

<script>
/**
 *
 * 按钮, 登录,
 * 获取验证码
 */
import '@/utils/flex.js'
import { phoneReg } from '@/utils/utils'
import { activityLogin, sendSms } from '@/api'
import { XInput, Countdown, XDialog } from 'vux'
import activeDialog from '@/components/active-invite-dialog.vue'
import activeMixin from '@/mixins/active-mixin'

export default {
  name: 'App',
  components: {
    XInput,
    Countdown,
    activeDialog,
    XDialog
  },
  mixins: [activeMixin],
  data: function() {
    return {
      active: [
        {
          title: ' 1.邀请人奖励机制：',
          children: [
            '(1)被邀请人数为1<X≤5，开卡激活成功，邀请人奖励25元；',
            '(2)被邀请人数为5<X≤10，开卡激活成功，邀请人奖励40元；',
            '(3)被邀请人数为10<X≤20，开卡激活成功，邀请人奖励50元；',
            '(4)被邀请人数为20<X≤50，开卡激活成功，邀请人奖励80元；',
            '(5)被邀请人数为X>50，开卡激活成功，邀请人奖励100元； '
          ]
        },
        { title: '2.被邀请人申卡激活成功后，可获得25元红包奖励；', children: [] },
        { title: '3.红包奖励发放后，将发放到用户的账户中，可进行绑卡提现；', children: [] },
        { title: '4.邀请人奖励上限为100元； ', children: [] },
        { title: '5.被邀请人在分享后的页面快捷登录成功且申卡并激活成功视为邀请成功； ', children: [] },
        { title: '6.同一用户邀请开卡得奖励和拼单办卡赢奖励两个活动只能参与一个;  ', children: [] },
        { title: '7.本活动规则最终解释权为用卡王所有。', children: [] }
      ],
      descArr: [
        '最全信用卡卡库',
        '白金卡90%通过率',
        '最新信用卡优惠活动',
        '智能提额工具'
      ],
      protocolFlag: false,
      login: false,

      inviteM: undefined,
      selfM: undefined,
      // 验证码
      time: 45,
      start: false,

      mobile: undefined,
      vcode: undefined

    }
  },
  computed: {

  },
  created() {
    const _urlQueryObj = this.$route.query
    this.inviteM = _urlQueryObj.inviteM
    this.setDocumentTitle('邀请开卡得奖励')
  },
  methods: {
    init() {

    },
    fetchData() {

    },
    getCode() {
      if (!phoneReg(this.mobile)) {
        return this.$vux.toast.text('手机号格式不正确', 'middle')
      }
      this.start = true
      const params = {}
      params.mobile = this.mobile
      params.type = 0
      sendSms(params).then(res => {
        this.$vux.toast.show({
          text: res.message,
          type: res.code == 1 ? 'success' : 'warn'
        })
      })
    },
    submit() {
      const params = {}
      params.mobile = this.mobile
      params.vcode = this.vcode
      params.inviteMobile = this.inviteM
      params.type = 1 // 1 邀请好友开卡
      if (!this.protocolFlag) {
        return this.$vux.toast.text('请阅读并同意协议', 'middle')
      }
      // 登录接口
      activityLogin(params).then(res => {
        if (res.code != 1) {
          this.showToast('middle', 'warn', res.message)
        } else {
          this.login = true
        }
      })
    },
    goPage() {
      this.$router.push('/userProtocol')
    },
    finish() {
      this.start = false
      this.time = 30
    },
    handleAgree() {
      this.protocolFlag = !this.protocolFlag
    }
  }
}
</script>

<style lang="less">
  @import '~vux/src/styles/reset.less';
  @media screen and (min-width: 520px) {

  }
  .title-c{
    color:#B5B3CE;
    div{
      color:#B5B3CE
    }
  }
  .group-wrap{
    background:#2A2967;
  }
  .content{
    box-sizing: border-box;
    position: relative;
    padding-bottom: 20px;
    width: 100%;
    .block{
      width: 3.45rem;
      border-radius: 10px;
      margin: 0 auto;
      background:transparent;
      margin-bottom:15px;
    }
    .c-top-wrap{
      position: absolute;
      top: .17rem;
      left: .24rem;
      width: 3.25rem;
      height: .66rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .c-top-left{
        width: 2.1rem;
        .money{
          font-size:16px;
          color:#FF005E;
          margin-left:.15rem;
        }
      }
      .c-top-right{
        width: 1.15rem;
        height: .66rem;
        display: flex;
        justify-content: center;
        align-items: center;
        border-left: 1px dashed #64309B;
      }
    }
  }
  .btn-color{
    background-image: linear-gradient(left,#C046F0,#CE23C5);
    background: -webkit-linear-gradient(left,#CE23C5,#CE23C5);
    color:#FFFFFF;
    display: flex;
    justify-content: center;
  }
  .dest-top{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    >div{
      width: 50%;
    }
  }
  .chameleon{
    position: relative;
    margin: 5px 0 5px;
    img{
      position: absolute;
      top: 4px;
      left: .14rem;
      width: 11px;
      height: 11px;
    }
    span{
    margin-left:.3rem;
    background-image: linear-gradient(to right, #FFEFD5, #F1CDA2);
    background: -webkit-linear-gradient(to right, #FFEFD5, #F1CDA2);
    background-clip: text;
    -webkit-background-clip: text;
    color: transparent;
    }
  }
  .active-input-wrap{
  width: 100%;
  border-radius: 20px;
  overflow: hidden;
  position: relative;
  background: #ffffff;
  height: 40px;
  display: flex;
  align-items: center;
  .weui-cell{
    padding: 0 .18rem!important;
    width: 100%;
    font-size: 16px;
    height: 16px;
    line-height: 16px;
  }
  input{
    font-size: 16px;
    height: 16px;
    line-height: 16px;
    background: transparent;
    width: 100%;
  }
  .code-span{
    color: #E44E3F;
    font-size: 15px;
  }
  .disabled{
    color: #999999
  }
}
</style>
