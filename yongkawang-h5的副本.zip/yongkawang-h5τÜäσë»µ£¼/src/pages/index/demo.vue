<template>
  <div>
    <p>
      <a href="mqqapi://card/show_pslcard?src_type=internal&version=1&uin=123456" style="display:block;" /> qq交流
    </p>
  </div>
</template>

<script>
export default {

}
</script>
<style scoped>

</style>
