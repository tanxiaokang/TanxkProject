<template>
  <div class="protocol">
    <div>
      <div class="title">
        抽奖规则
      </div>
    </div>
  </div>
</template>

<script>
import '@/utils/flex.js'
export default {
  name: 'Protocol',
  data() {
    return {

    }
  },
  created() {
    this.setDocumentTitle('抽奖规则')
  }
}
</script>

<style lang="less" scoped>
     .protocol{
         .tip{
             font-family: PingFangSC-Semibold;
             font-size: 0.12rem;
             color: #333333;
             text-align: center;
             padding-bottom: 1rem;
             padding-top: 1rem;
         }
         padding: 1rem;
         .title{
             font-weight: bold;
             font-size: 0.12rem;
             margin: 1rem 0;
         }
         .content{
           box-sizing: border-box;
             padding: 0 1rem;
             font-size: 0.835rem;
             color:#666666;
             letter-spacing: 2px;
             line-height: 1.4rem;
         }
     }
</style>
