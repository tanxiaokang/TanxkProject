<template>
  <div class="result">
    <img src="@/assets/assemble/suc.png" alt="">
    <p>
      <span>您的资料已提交成功</span><br>
      <span>48小时内有专人为您服务，请留意接听手机</span>
    </p>
    <div class="public-btn" @click="handleInstallApp">
      下载APP
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {

    }
  },
  created() {
    this.setDocumentTitle('申请结果')
    this.$vux.loading.hide()
  },
  methods: {
    handleInstallApp() {
      window.location.href = 'https://a.app.qq.com/o/simple.jsp?pkgname=cardking.rzzh.com'
    }
  }
}
</script>
<style lang="less">
.result{
    padding-top:71px;
    text-align: center;
    img{
        width: 1.24rem;
        height: 1.25rem;
        margin-bottom:25px;
        vertical-align: middle;
    }
    p{
        text-align: center;
        color: #3B4257;
    }
    .public-btn{
        background: #FFDA33;
        width:3.43rem;
        height: 40px;
        line-height: 40px;
        color: #161921;
        font-size: 16px;
        border-radius: 20px;
        margin:35px auto 0;
    }
}
</style>
