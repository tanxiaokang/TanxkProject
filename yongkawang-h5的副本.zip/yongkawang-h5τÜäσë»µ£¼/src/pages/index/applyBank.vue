<template lang="pug">
  div.apply-bank(style="overflow: hidden;background: #ffffff;")

    //- 征信评分 --------------------------------------------------------------
    div(
      style="border-bottom:10px solid #f3f3f3;padding:2rem 0 1.2rem 0;position: absolute;width:100%;background:#ffffff;left:0;top:0")
      div.creditRating(style="display: flex;")
        div(
          style="width:30%;color: #EC2828;font-family: PingFangSC-Semibold;font-size: 1.125rem;text-align: center;")
          |征信评分
        div(style="width:70%;")
            div(style="display:flex;align-items: center;")
              div(style="width:5%;color: #CCCCCC;margin-right:0.2rem")
                |0
              div(style="width:72%;position: relative;")
                div(:style="{'position':'absolute','left':passRate-8+'%','top':'-1.6rem','width':'2rem','height':'1.5rem','z-index':981}")
                  img.full-img(src="@/assets/91.png")
                div(:style="{'position': 'absolute','left':passRate-8+'%','top':'-1.48rem','width':'2rem','z-index':989,'font-size':'0.835rem','color': '#FFFFFF','text-align':'center'}")
                  |{{creditRating}}
                div(:style="{'position': 'absolute','left':0,'top':0,'width': passRate+'%','z-index':981,'background':'#EC2828','height':'6px','border-radius': '3px'}")
                div(style="position: absolute;left:0;top:0;width: 100%;z-index:980;background:#CCCCCC;height:6px;border-radius: 3px;")
              div(style="width:5%;color: #CCCCCC;padding-left:0.4rem")
                |100
      div.credit-score(
        style="display: flex;margin-top:1.4rem")
          div(
          style="width:30%;color: #1872DB;font-family: PingFangSC-Semibold;font-size: 1.125rem;text-align: center;")
            |申卡通过率
          div(
            style="width:70%;")
            div(
              style="display:flex;align-items: center;")
              div(
                style="width:5%;color: #CCCCCC;margin-right:0.2rem")
                |0
              div(
                style="width:72%;position: relative;")
                  div(
                    :style="{'position': 'absolute','left':passRate-8+'%','top':'-1.6rem','width':'2rem','height':'1.5rem','z-index':981}")
                    img.full-img(src="@/assets/90.png")
                  div(
                    :style="{'position': 'absolute','left':passRate-8+'%','top':'-1.48rem','width':'2rem','z-index':989,'font-size':'0.835rem','color': '#FFFFFF','text-align':'center'}")
                    |{{passRate}}
                  div(
                    :style="{'position': 'absolute','left':0,'top':0,'width': passRate+'%','z-index':981,'background':'#1872DB','height':'6px','border-radius': '3px'}")
                  div(
                    style="position: absolute;left:0;top:0;width: 100%;z-index:980;background:#CCCCCC;height:6px;border-radius: 3px;")
              div(
                style="width:5%;color: #CCCCCC;padding-left:0.4rem"
              ) 100%

    //-表单 --------------------------------------------------------------
    div.bottom-wrap(
      ref='bottomWrap'
      style="overflow-y:scroll;width:100%;overflow-x: hidden;overflow-y: scroll;position: absolute;top: 9em;")
      div
        div.block-title 身份信息
        div.certContent
            div(style="width:80%")
              x-input(
                required
                title="姓名"
                v-model="userName"
                placeholder="请填写中文姓名")
              div(
                style="border-bottom:1px solid #f3f3f3;width:120%;margin-left:1rem")
              x-input(
                required
                type='number'
                title="身份证号"
                v-model="idCard"
                :max='18'
                placeholder="请输入身份证号")
              div(
                style="border-bottom:1px solid #f3f3f3;width:120%;margin-left:1rem")

        div(style="border-bottom:10px solid #f3f3f3")
          div.modal-item
            div(style="width:80%")
              x-input(
                required
                title="文化程度"
                v-model="education"
                placeholder="请选择文化程度"
                @click.native="selectItem('4')"
                disabled)

            div(style="width:20%")
              div(
                style="display:flex;align-items: center;justify-content: flex-end;padding-right:1rem")
                div(
                  v-show="education"
                  style="color: #EC2828;font-size: 0.75rem;"
                ) +{{educationScore}}分
                img(src="@/assets/22.png" style="width:0.5rem;height:0.9rem;margin-left:0.2rem")

        div.block-title 收入信息
        div(
          style="border-bottom:10px solid #f3f3f3")
            div.modal-item.xx
                div(style="width:80%;")
                  x-input(
                    required title="信用卡负债比例" v-model="liabilitiesRatio" placeholder="请选择比例" @click.native="selectItem('11')" disabled)
                    div(slot='label' style="font-size:0.9375rem" @click.stop="RosilLimitFn")
                      div 信用卡
                      div(style="display:flex;align-items: center;")
                        div 负债比例
                        img(src="@/assets/23.png" style="width:16px;margin-left:0.2rem")

                div( style="width:20%;" @click="selectItem('11')")
                    div(
                      style="display:flex;align-items: center;justify-content: flex-end;padding-right:1rem")
                        div(
                          v-show="liabilitiesRatio"
                          style="color: #EC2828;font-size: 0.75rem;"
                        ) {{liabilitiesRatioScore === '-2'?liabilitiesRatioScore:'+'+liabilitiesRatioScore}}分
                        img(src="@/assets/22.png" style="width:0.5rem;height:0.9rem;margin-left:0.2rem")
        div.block-title 联系信息
        div.contacts
            div(
              style="width:80%")
                x-input(title="手机号" v-model="applyMobile" type='tel' is-type="china-mobile" :max='11' placeholder="请输入手机号")
            div(
              style="border-bottom:1px solid #f3f3f3;width:120%;margin-left:1rem")
            div.vertCode
                div(
                  style="width:80%")
                    x-input(title="验证码" v-model="code" type='tel' :max='6' placeholder="请输入验证码")
                x-button(
                  @click.native="getCode" slot="right" mini plain
                  :disabled="disabled"
                  :style="{'border-radius':'2px','height':'40px','line-height':'40px','font-family':'PingFang-SC-Medium','padding':'0','min-width':'50px','border':'none'}")
                  countdown(
                    v-show="!show"
                    v-model="time"
                    :start="start" @on-finish="finish")
                  div(
                    v-show="show"
                    :style="{'color':'#3478F8','font-size':'0.8015rem','font-family':'PingFang-SC-Medium','height':'40px','text-align':'center','line-height':'40px'}"
                  ) 获取
            div(
              style="border-bottom:1px solid #f3f3f3;width:120%;margin-left:1rem")
        div(
          style="color:rgb(220, 93, 93);font-size:0.8125rem;padding:1rem;"
        ) 请选择银行工作人员与您当面核实信息的时间和地点
        div.modal-item
            div(style="width:80%")
              x-input(
                required title="时间"
                v-model="doCardTime"
                placeholder="请选择上门时间"
                @click.native="selectItem('13')"
                disabled)

            div( style="width:20%")
              div(style="display:flex;align-items: center;justify-content: flex-end;padding-right:1rem")
                img(src="@/assets/22.png" style="width:0.5rem;height:0.9rem;margin-left:0.2rem")

        div.modal-item
            div(style="width:80%")
              x-input(
                required title="地点"
                v-model="doCardAddress"
                placeholder="请选择上门地点"
                @click.native="selectItem('14')"
                disabled)

            div( style="width:20%")
              div(style="display:flex;align-items: center;justify-content: flex-end;padding-right:1rem")
                img(src="@/assets/22.png" style="width:0.5rem;height:0.9rem;margin-left:0.2rem")

        x-address(
          style="font-size:.83em"
          title="地区"
          v-model="addressDefault"
          :list="addressData"
          @on-shadow-change="onShadowChange"
          placeholder="请选择省 市 区")
        div
            x-input(
              required
              text-align='right'
              title="详细地址"
              v-model="addressDetail"
              placeholder="请输入详细地址")
        div(
          style="background:#f3f3f3;padding:2rem 0")
            div(
              style="display:flex; align-items: center;padding-left:0.4rem")
                check-icon(:value.sync="checkIcon")
                div
                    span(
                      style="color: #999999;font-size:0.8125rem"
                    ) 阅读并同意
                    span(@click="goProtocol" style="color:#5589F1 ;font-size:0.8125rem"
                  ) 《{{bankName}}银行办卡协议》
            div.btn(@click="nextStep" :style="btnBg") 下一步
            div(
              style="color:#E32B2B;font-size:0.8125rem;text-align:center;margin-top:1.25rem")
                div 注：填写真实信息有助于提高申卡通过率！
                div(
                  style="margin-top:0.1rem"
                ) 通过率以最终系统审核为准。

    //- 弹出层 --------------------------------------------------------------
    div(TransferDom)
      div.modalTrans
          x-dialog.dialog-demo(v-model="SuccessModal")
              div(
                style="color: #333333;font-size:1.125rem;font-weight:bold;padding:1rem 0"
              ) 评估成功
              div(
                style="color: #333333;padding:0.4rem 0 0.5rem 0"
              ) 您的征信评分为 {{creditRating}}
              div(
                style="color: #333333;padding:0.4rem 0 2rem 0"
              ) 申卡通过率为 {{passRate}}%
              div(
                style="color:#EC2828;font-size:13px；padding:0 1rem;padding:0 1rem"
              ) 请保持手机畅通，审核人员会联系您完成最终审核！
              div(@click="goIndex" style="color: #1872DB;text-align: center;padding:1rem;border-top:1px solid #f3f3f3"
            ) 我知道了
    div(TransferDom)
      x-dialog.dialog-demo(v-model="RaoiModal")
          div(
            style="color: #333333;font-size:1.125rem;font-weight:bold;padding:1rem 0"
          ) 信用卡负债比例
          div(
            style="color: #333333;padding:0.4rem 1rem 2rem 1rem"
          ) 信用卡负债比例%= 所有卡片使用额度总和 / 所有银行授信额度总和
          div(@click="RaoiModal=false" style="color: #1872DB;text-align: center;padding:1rem;border-top:1px solid #f3f3f3"
        ) 我知道了
    div(TransferDom)
      x-dialog.dialog-demo(v-model="showModal")
          checklist(v-show="selectItemModal == 4" title="文化程度" :options="educationList" v-model="educationValue" :max="1" @on-change="educationChange")
          checklist(v-show="selectItemModal == 11" title="信用卡负债比例" :options="bankDebtRatioList" v-model="bankDebtRatioValue" :max="1" @on-change="bankDebtRatioChange")
          checklist(v-show="selectItemModal == 13" title="请选择" :options="meetTimeList" v-model="meetTimeValue" :max="1" @on-change="meetTimeChange")
          checklist(v-show="selectItemModal == 14" title="请选择" :options="meetAddressList" v-model="meetAddressValue" :max="1" @on-change="meetAddressChange")

</template>

<script>
// import '@/utils/flexApply'
import { agreementUrl, sendSms, applyCard } from '@/api'
import { XAddress, XInput, Countdown, XButton, XDialog, Checklist, CheckIcon, TransferDomDirective as TransferDom, ChinaAddressV4Data } from 'vux'
export default {
  name: 'ApplyBank',
  directives: {
    TransferDom
  },
  components: {
    XInput,
    Countdown,
    XButton,
    XDialog,
    Checklist,
    CheckIcon,
    XAddress
  },
  data() {
    // const liabilitiesRatioOption = [
    //   {
    //     value: 0,
    //     liabilitiesRatioScore: 20,
    //     mate: '60%以上'
    //   },
    //   {
    //     value: 1,
    //     liabilitiesRatioScore: 40,
    //     mate: '30%～60%'
    //   },
    //   {
    //     value: 2,
    //     liabilitiesRatioScore: 60,
    //     mate: '30%以下'
    //   },
    //   {
    //     value: 3,
    //     liabilitiesRatioScore: 5,
    //     mate: '没有信用卡'
    //   }
    // ]

    // const educationOption = [
    //   {
    //     value: 0,
    //     educationScore: 1,
    //     mete: '初中及以下'
    //   },
    //   {
    //     value: 1,
    //     educationScore: 5,
    //     mete: '高中'
    //   },
    //   {
    //     value: 2,
    //     educationScore: 10,
    //     mete: '中专'
    //   },
    //   {
    //     value: 3,
    //     educationScore: 40,
    //     mete: '大学及以上'
    //   }
    // ]
    return {
      pleaseChoose: '',
      pleaseMux: '',
      isShowClaer: false,
      RaoiModal: false,
      showClearFalse: false,
      SuccessModal: false,

      mobile: undefined,

      /** 银行信息,后台接口返回 */
      bankName: undefined,
      bankId: undefined,
      bankNCode: undefined,

      /** 分数**/
      educationScore: 0,
      liabilitiesRatioScore: 0,
      /** 创建订单状态 */
      userName: '',
      idCard: '',
      applyMobile: '',
      age: '',
      education: '',
      liabilitiesRatio: '',
      doCardTime: '',
      doCardAddress: '',
      code: '',
      /** 订单传餐**/
      userNameT: '',
      idCardT: '',
      mobileT: '',
      ageT: '',
      nativePlaceT: '',
      educationT: '',
      liabilitiesRatioT: '',
      creditRatingT: '',
      passRateT: '',
      doCardTimeT: '',
      doCardAddressT: '',
      codeT: '',
      time: 59,
      show: true,
      codeBg: '#DDDDDD',
      start: false,
      disabled: false,
      showModal: false,
      educationList: ['初中及以下', '高中', '中专', '大学及以上'],
      bankDebtRatioList: ['60%以上', '30%～60%', '30%以下', '没有信用卡'],
      meetTimeList: ['工作日(周一至周五)', '周六或周日', '任何时间'],
      meetAddressList: ['公司地址', '现居住地址'],
      addValue: [''],
      educationValue: [''],
      occupationValue: [''],
      addressValue: [''],
      monthMonthValue: [''],
      bankNumValue: [''],
      bankLimitValue: [''],
      bankDebtRatioValue: [''],
      meetTimeValue: [''],
      meetAddressValue: [''],
      selectItemModal: '',
      checkIcon: false,
      addressData: ChinaAddressV4Data,
      addressDefault: [],
      preAddress: '',
      addressDetail: '',
      names: '',
      appayType: ''

    }
  },
  computed: {
    btnBg() {
      return { background: '#4D4D4D', marginTop: '1rem', color: '#ffffff', border: '1px solid #f1f1f1' }
    },
    creditRating() {
      return parseInt(this.educationScore) + parseInt(this.liabilitiesRatioScore)
    },
    passRate() {
      return Number(parseFloat(this.creditRating * 100 / 100).toFixed('1'))
    }
  },
  created() {
    const html = document.documentElement
    html.style.fontSize = '16px'
    this.setDocumentTitle('申卡入口')
    this.$vux.loading.hide()

    const urlQuery = this.$route.query
    this.mobile = urlQuery.m
    this.applyMobile = urlQuery.m
    this.bankId = urlQuery.bId
    this.creditNo = urlQuery.cNo
    this.idCard = urlQuery.idCard || ''
    this.userName = urlQuery.realName || ''

    // this.initPage()
  },
  methods: {
    initPage() {
      this.fetchData()
    },
    fetchData() {
      const params = {}
      params.bankId = this.bankId
      agreementUrl(params).then(res => {
        this.bankCode = res.resultObj.bankCode
        this.bankId = res.resultObj.bankId
        this.bankName = res.resultObj.bankName
        this.creditAgreement = res.resultObj.creditAgreement
      })
    },
    onShadowChange(ids, names) {
      this.preAddress = names[0] + names[1] + names[2]
    },
    goIndex() {
      this.SuccessModal = false
      window.h5toNative = function() {
        try {
          Client.callBackDataH5ForClient('jump', '')
        } catch (error) {

        }
      }
      window.h5toNative()
    },
    RosilLimitFn() {
      this.RaoiModal = true
    },
    goProtocol() {
      this.$router.push({
        name: 'protocol',
        params: {
          id: this.bankName
        }
      })
    },
    modalSure() {
      this.showModal = false
    },
    // 倒计时后处理
    finish(index) {
      this.start = false
      this.show = true
      this.disabled = false
      this.time = 29
    },
    getCode() {
      if (!this.applyMobile) {
        this.showToast('', 'text', '请输入手机号')
        return
      }
      this.start = true
      this.show = false
      this.disabled = true

      const params = {}
      params.mobile = this.applyMobile
      params.type = 1
      sendSms(params).then(res => {

      })
    },
    selectItem(e) {
      this.showModal = true
      this.selectItemModal = e
    },
    educationChange(val, label) {
      this.showModal = false
      if (val.length === 0) {
        this.educationScore = 0
        this.educationT = ''
        this.education = ''
        return
      }

      this.education = val[0]
      this.educationScore = 1
      if (val[0] === '初中及以下') {
        this.educationT = 0
        this.educationScore = 1
      } else if (val[0] === '高中') {
        this.educationT = 1
        this.educationScore = 5
      } else if (val[0] === '中专') {
        this.educationT = 2
        this.educationScore = 10
      } else {
        this.educationT = 3
        this.educationScore = 40
      }
      this.showModal = false
    },
    bankDebtRatioChange(val, label) {
      this.showModal = false
      this.pleaseMux = val[0]
      if (val.length === 0) {
        this.liabilitiesRatioScore = 0
        this.liabilitiesRatioT = ''
        this.liabilitiesRatio = '请选择信用卡负债比'
        return
      }
      this.liabilitiesRatio = val[0]
      this.liabilitiesRatioScore = -2

      if (val[0] === '60%以上') {
        this.liabilitiesRatioT = 0
        this.liabilitiesRatioScore = 20
      } else if (val[0] === '30%～60%') {
        this.liabilitiesRatioT = 1
        this.liabilitiesRatioScore = 40
      } else if (val[0] === '30%以下') {
        this.liabilitiesRatioT = 2
        this.liabilitiesRatioScore = 60
      } else {
        this.liabilitiesRatioT = 3
        this.liabilitiesRatioScore = 5
      }
    },

    meetTimeChange(val, label) {
      this.doCardTime = val[0]

      if (val[0] === '工作日') {
        this.doCardTimeT = 0
      } else if (val[0] === '周六或周日') {
        this.doCardTimeT = 1
      } else {
        this.doCardTimeT = 2
      }
      this.showModal = false
    },
    meetAddressChange(val, label) {
      this.doCardAddress = val[0]
      if (val[0] === '公司地址') {
        this.doCardAddressT = 0
      } else {
        this.doCardAddressT = 1
      }
      this.showModal = false
    },
    nextStep() {
      if (!this.userName) {
        this.showToast('', 'text', '姓名不能为空')
        return
      }
      if (!this.idCard) {
        this.showToast('', 'text', '身份证号不能为空')
        return
      }
      if (!this.educationT && this.educationT !== 0) {
        this.showToast('', 'text', '请选择文化程度')
        return
      }

      if (!this.liabilitiesRatioT && this.liabilitiesRatioT !== 0) {
        this.showToast('', 'text', '请选择负债比例')
        return
      }

      if (!this.mobile) {
        this.showToast('', 'text', '请输入手机号')
        return
      }
      if (!this.code) {
        this.showToast('', 'text', '请输入验证码')
        return
      }

      if (!this.doCardTimeT && this.doCardTimeT !== 0) {
        this.showToast('', 'text', '请选择见面日期')
        return
      }
      if (!this.doCardAddressT && this.doCardAddressT !== 0) {
        this.showToast('', 'text', '请选择见面地点')
        return
      }

      if (this.addressDefault.length === 0) {
        this.showToast('', 'text', '请选择地址')
        return
      }
      if (!this.addressDetail) {
        this.showToast('', 'text', '请输入详细地址')
        return
      }
      if (!this.checkIcon) {
        this.showToast('', 'text', '请同意协议')
        return
      }

      const arg = {}
      arg.address = this.preAddress + this.addressDetail
      arg.addressType = this.doCardAddressT
      arg.bankId = this.bankId
      arg.agreementUrl = this.creditAgreement
      arg.creditNo = this.creditNo
      arg.applyMobile = this.applyMobile
      arg.mobile = this.applyMobile
      arg.doCardAddress = this.doCardAddressT
      arg.realName = this.userName
      arg.idCard = this.idCard
      arg.code = this.code
      arg.education = this.educationT
      arg.liabilitiesRatio = this.liabilitiesRatioT
      arg.doCardTime = this.doCardTimeT
      arg.creditRating = this.creditRating
      arg.passRate = this.passRate

      applyCard(arg).then(data => {
        if (data.code === 1) {
          // this.SuccessModal = true
        } else {
          this.showToast('', 'text', data.message)
        }
      })
    }
  }
}
</script>

<style lang="less" >
    .weui-cell:before{
        display: none;
    }
    .weui-cells:after{
        display: none;
    }
    .weui-cells:before{
        display: none;
    }
    .btn{
        width:92%;
        height:2.7778rem;
        display: flex;
        margin: 0 auto;
        align-items: center;
        justify-content: center;
        color:#666666;
        font-size:1em;
        border-radius: 2px;
        font-family:PingFang-SC-Medium;
        color:#ffffff;
    }

    .apply-bank{
        .weui-cell__hd{
          width:42%!important;
          font-size: 0.9rem!important;
        }
        .weui-input{
          font-size: 0.8425rem!important;
        }
        .weui-cell__bd{
          width:52%!important;
        }
        .weui-cells__title{
            font-family: PingFangSC-Medium;
            font-size: 1.125rem;
            color: #333333;
        }
        .modalTrans{
            .weui-cell__bd{
                color: #333333!important;
                text-align: left!important;
                font-size: 0.875rem!important;
            }
        }
        overflow: hidden;

        .block-title{
            font-family: PingFangSC-Semibold;
            font-size: 1.25rem;
            color: #333333;
            padding: 1.875rem 0 1rem 0;
            margin:0 1.2rem ;
            border-bottom: 1px solid #f3f3f3;
            font-weight:700
        }
        .creditRating{
            .range-quantity{
                background-color: #EC2828;
            }
            .range-handle{
                background-color: rgb(239, 36, 28);
            }
        }
        .credit-score{
            .range-quantity{
                background-color: #1872DB
            }
            .range-handle{
                background-color: rgb(24, 114, 219);
            }
        }
        .modal-item{
            display: flex;
            align-items: center;
            border-bottom: 1px solid #f3f3f3;
        }
        .xx{
            .weui-label{
                color: #0d6fde!important;
            }
        }
        .contacts{

            .vertCode{
                display: flex;
            }
        }
    }
</style>
