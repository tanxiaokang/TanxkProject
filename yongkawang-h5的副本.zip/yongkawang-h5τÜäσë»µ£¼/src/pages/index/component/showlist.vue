<template>
  <div>
    <div class="content-wrap">
      <div class="content-wrap-title">
        <h4 style="font-size:18px;color:#161921;">
          {{ title }}
        </h4>
        <span @click="handleMoreCard(types)">更多<span class="arrow" /></span>
      </div>
      <div class="content-wrap-imgs">
        <div v-for="(item,ind) in datalist" :key="ind" class="content-wrap-imgs-div" @click="handleSignleCard(item.creditNo,item.creditName)">
          <p style="width:.96rem;height:.6rem;">
            <img :src="item.smallUrl" alt="" style="width:.96rem;height:.6rem;">
            <span ref="type" style="display:none">{{ item.assembleType }}</span>
          </p>
          <p style="font-size:12px;text-align:center;margin:6px 0 19px 0;">
            已拼<countup :start-val="1" :end-val="item.grantCount" :duration="2" class="red" :options="{'useGrouping':false}" />张卡
          </p>
          <p style="width:.95rem;height:.26rem;line-height:.26rem;background:#F4402E;color:#fff;text-align:center;border-radius:20px;">
            拼团
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import mixins from '@/mixins/index.js'
import { Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup } from 'vux'
import { Stream } from 'stream'
export default {
  name: 'ShowList',
  filters: {},
  components: {
    Countup
  },
  mixins: [mixins],
  props: {
    datalist: {
      type: Array
    },
    title: {
      type: [String],
      default: '【商旅出行】'
    },
    types: {
      type: [String, Number]
    }
  },
  data() {
    return {
      arr: 3,
      endVal: 28321
    }
  },
  created() {
    console.log(11, this.dataList, this.types)
  },
  methods: {
    handleSignleCard(creditNo, creditName) {
      this.$uweb.trackEvent('按钮', 'more', creditName)
      console.log(11, creditNo)
      // 单个卡片跳转
      this.$router.push({
        path: './cardykwDetail',
        query: {
          creditNo: creditNo,
          form: 'ykw'

        }
      })
    },
    handleMoreCard(types) {
      this.$uweb.trackEvent('按钮', 'more', types)
      // 更多卡片跳转
      this.$router.push({
        path: './cardList',
        query: {
          type: types,
          form: 'ykw'
        }
      })
    }
  }

}
</script>
<style scoped>
.arrow{
  display: inline-block;
  width:10px;
  height:10px;
  border-top:1px solid #161921;
  border-right:1px solid #161921;
  -webkit-transform: translate(0,0%) rotate(45deg);
  transform: translate(0,0%) rotate(45deg);
}
.red{
  color: #F4402E;
}
</style>
<style lang="less" scoped>
.content-wrap{
      width:3.43rem;
      margin:0 auto 16px;
      background: #fff;
      padding-top:0.16rem;
      padding-bottom:.28rem;
      border-radius: 10px;
      &-title{
        padding-right:14px;
        display: flex;
        justify-content: space-between;
      }
      &-imgs{
        width:3.43rem;
      margin:19px auto 0 auto;
      display: flex;
      justify-content: space-around;
      &-div{
        width:0.96rem;
      // border:1px solid red;
        // height:1.43rem;
      }
    }
    }
</style>
