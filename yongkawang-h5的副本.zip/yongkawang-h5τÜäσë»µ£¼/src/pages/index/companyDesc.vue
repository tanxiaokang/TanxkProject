<template>
  <div class="protocol">
    <div>
      <div class="content">
        <div class="title">
          北京润泽智慧科技有限公司，由前百度、阿里、51信用卡等互联网行业资深人士倾力打造，清华统计学博士、宜信风控等，资深专家组成的具有丰富经验的团队。
        </div>
        <div class="title">
          润泽创立即以“成为一家以AI智能技术改变传统科技的企业”为愿景，利用AI技术实现改变传统人工效率等策略，专注于高效、安全的服务为用户提供精准、专业的技术服务。公司总部位于北京市朝阳区望京SOHO。
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Protocol',
  data() {
    return {
      bankName: undefined
    }
  },
  created() {
    this.bankName = this.$route.params.id
    this.setDocumentTitle('公司介绍')
  }
}
</script>

<style lang="less" scoped>
     .protocol{
        font-family: PingFangSC;
        font-size: 14px;
        color: #3b4257;
        padding: 16px 10px;
        box-sizing: border-box;
         .title{
             text-indent: 2em;
             font-size:14px;
             line-height: 22px;
             padding-bottom:4px;
         }
         .content{
            font-size: 14px;
            color:#3b4257;
            letter-spacing: 1px;
            line-height: 22px;
         }
     }
</style>
