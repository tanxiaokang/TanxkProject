<template lang='pug'>
  div.page-container
    div(style='position: absolute;top: 0;right: 0;background: rgba(0,0,0,0.5);padding: 10px 8px;color: red;border-radius: 50%;' @click='share()') 分享
    div.imgwrap(v-for='(item,ind) in imgs' @click='handleJumpto(ind)')
      img.imgwrap-img(
        :src='item.imgurl'
      )
    div.content-wrap
      div| 具体优惠活动信息以银行官网为准
</template>
<script>
import wx from 'weixin-js-sdk'
import '@/utils/flex.js'
import { getWXConfigSignature } from '@/api/index.js'
export default {
  name: 'Highpt',
  data: function() {
    return {
      imgs: [
        { imgurl: require('@/assets/bank_one.png') },
        { imgurl: require('@/assets/bank_two.png') },
        { imgurl: require('@/assets/bank_three.png') },
        { imgurl: require('@/assets/bank_four.png') },
        { imgurl: require('@/assets/bank_five.png') }
      ],
      local: { ind: '', mes: {}},
      obj: {
        channel: ''
      }
    }
  },
  created() {
    this.setDocumentTitle('测试wx2次分享')
    this.$vux.loading.hide()
    window.appInvokeH5 = this.appInvokeH5
    this.init()
  },
  methods: {

    init() {
      wx.checkJsApi({
        jsApiList: ['updateAppMessageShareData', 'updateTimelineShareData', 'onMenuShareTimeline', 'onMenuShareAppMessage'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
        success: function(res) {

        }
      })
      const params = {}
      params.url = (window.location.href)
      getWXConfigSignature(params).then(res => {
        if (res.code == 1) {
          this.local.mes = res.resultObj
          this.$vux.loading.hide()
          wx.config({
            debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: this.local.mes.appId, // 必填，公众号的唯一标识
            timestamp: this.local.mes.timestamp, // 必填，生成签名的时间戳
            nonceStr: this.local.mes.nonceStr, // 必填，生成签名的随机串
            signature: this.local.mes.signature, // 必填，签名
            jsApiList: ['updateAppMessageShareData', 'updateTimelineShareData', 'onMenuShareTimeline', 'onMenuShareAppMessage'] // 必填，需要使用的JS接口列表
          })
          wx.ready(function() { // 需在用户可能点击分享按钮前就先调用
            const obj = {
              // 分享给朋友
              title: '注册得888金币(可兑现金)', // 分享标题
              desc: this.mixinsLocal.desc, // 分享描述
              link: window.location.href, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
              imgUrl: 'https://ftp.runzezhihui.com/cycleImage/2019-05-29/i186172451792875520/i186172451792875520.png', // 分享图标
              success: function() {
                // 设置成功
                alert('分享成功')
              }
            }
            wx.updateAppMessageShareData(obj)
            wx.updateTimelineShareData(obj)
            wx.onMenuShareTimeline(obj)
            wx.onMenuShareAppMessage(obj)
          })
        }
      })
    },
    handleJumpto(ind) {
      this.local.ind = ind
      window.callShareClient('login', '').then(res => {
        if (res == 'ok') {
          // 非app登录
          const ispc = this.IsPC()
          if (ispc == true) {
            // 如果是pc 端登录
            this.obj.channel = 'H5-Pc-haodai'
            this.jumptoThird(ind)
          } else {
            this.isMobile()
            this.jumptoThird(ind)
          }
        }
      }).catch(err => {
        console.log(888, err)
        window.appInvokeH5 = this.appInvokeH5
      })
    },
    IsPC() {
      var userAgentInfo = navigator.userAgent
      var Agents = ['Android', 'iPhone',
        'SymbianOS', 'Windows Phone',
        'iPad', 'iPod']
      var flag = true
      for (var v = 0; v < Agents.length; v++) {
        if (userAgentInfo.indexOf(Agents[v]) > 0) {
          flag = false
          break
        }
      }
      return flag
    },
    isMobile() {
      var u = navigator.userAgent
      var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1 // g
      var isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) // ios终端
      if (isAndroid) {
        // 这个是安卓操作系统
        this.obj.channel = 'App-Andior-haodai'
      }
      if (isIOS) {
        // 这个是ios操作系统
        this.obj.channel = 'App-Ios-haodai'
      }
    },
    jumptoThird(ind) {
      const _str = Number(ind)
      switch (_str) {
        case 0: this.$router.push({
          path: './applyCard',
          // 光大阳光白金卡
          query: {
            cid: 13223,
            channel: this.obj.channel,
            form: 'ykw'
          }
        })
          break
        case 1: this.$router.push({
          path: './applyCard',
          // 中信
          query: {
            cid: 12839,
            channel: this.obj.channel,
            form: 'ykw'
          }
        }); break
        case 2: this.$router.push({
          path: './applyCard',
          // 兴业睿白金卡  没有cid 编码
          query: {
            cid: 12839,
            channel: this.obj.channel,
            form: 'ykw'
          }
        }); break
        case 3: this.$router.push({
          // 中行长城国际  没有cid 编码
          path: './applyCard',
          query: {
            cid: 12839,
            channel: this.obj.channel,
            form: 'ykw'
          }
        }); break
        case 4:this.$router.push({
          // 华夏时尚白金卡
          path: './applyCard',
          query: {
            cid: 13176,
            channel: this.obj.channel,
            form: 'ykw'
          }
        }); break
        default:break
      }
      return
    },
    appInvokeH5(type, param) {
      switch (type) {
        case 'alreadyLogin':
          localStorage.setItem('userNo', param)
          this.jumptoThird(this.local.ind); break
        case 'ykwapp':
          alert(param)
          this.jumptoThird(this.local.ind); break
        case 'shareInfo':
          this.objdesc = {
            qqimageURL: 'https://ftp.runzezhihui.com/cycleImage/2019-05-28/i185809091686899712/i185809091686899712.png', // 事先部署到服务器 qq
            wximageURL: 'https://ftp.runzezhihui.com/cycleImage/2019-05-29/i186172451792875520/i186172451792875520.png', // 事先部署到服务器 wx
            title: '注册得888金币(可兑现金)',
            subtitle: '高权益高额度白金卡限时申请，高通过率，最快当天拿卡'
          }
          window.callShareClient('share', JSON.stringify(this.objdesc)); break
        // default:this.jumptoThird(this.local.ind); break
      }
    }

  }
}
</script>

<style lang="less" scoped>
.page-container{
  padding-top:3.16rem;
  background:url('../../assets/high_bg.png') no-repeat;
  background-size:100% 100%;
    .imgwrap{
        text-align: center;
        margin-bottom:.25rem;
        min-height:2.10rem!important;
        &-img{
          width:3.4rem;
          vertical-align: middle;
        }
    }
.content-wrap{
    padding-bottom: .16rem;
    div{
      text-align: center;
      color:#7B0014;
      font-size: .13rem;
      letter-spacing: 1px;
    }
}
}
</style>
