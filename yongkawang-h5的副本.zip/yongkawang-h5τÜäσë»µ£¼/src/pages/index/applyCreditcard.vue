<template lang="pug">
  div.apply-card(style="overflow: hidden;background: #ffffff;height:100vh;font-size:16px;")
    //-表单 --------------------------------------------------------------
    div.bottom-wrap(
      ref='bottomWrap'
      style="overflow-y:scroll;width:100%;overflow-x: hidden;overflow-y: scroll;position: absolute;")
      div
        div.certContent
            div(style="width:80%")
              x-input(
                label-width='90'
                title="姓&nbsp;&nbsp;&nbsp;&nbsp;名"
                v-model="userName"
                is-type='china-name'
                :show-clear='false'
                placeholder="请输入中文姓名")
        div.contacts
            div(style="width:80%")
                x-input(
                  title="手机号"
                   v-model="applyMobile"
                   label-width='90'
                   type='tel'
                   is-type="china-mobile"
                   :max='13'
                   mask='999 9999 9999'
                   :show-clear='false'
                   placeholder="请输入手机号")
            div.vertCode
                div(
                  style="width:80%")
                    x-input(
                      title="验证码"
                      v-model="code"
                      type='tel' :max='6'
                      label-width='90'
                      :show-clear='false'
                      placeholder="请输入验证码"
                      )
                x-button(
                  @click.native="getCode" plain mini
                  :disabled="disabled"
                  :style="{'padding':'0 20px 0 0','border':'none'}")
                  countdown(
                    v-show="!show"
                    v-model="time"
                    :start="start" @on-finish="finish")
                  div(
                    v-show="show"
                    :style="{'color':'#161921','font-size':'12px','font-family':'PingFang-SC-Medium','background':'#FFDA33','border-radius':'20px','padding':'4px','width':'75px'}"
                  ) 获取验证码
            div(style="width:100%")
                popup-picker(
                    title="月收入"
                    label-width='90'
                    value-text-align='left'
                    :data="monthList"
                    v-model="monthMoney"
                    @on-change='changeMonthmoney'
                    placeholder="请选择")
            div(style="width:100%")
                popup-picker(
                    class='time'
                    title="办卡时间"
                    value-text-align='left'
                    :data="timeList"
                    v-model="doCardTime"
                    @on-change='changeDocardTime'
                    placeholder="请选择")
            div(style="width:100%")
                x-address(
                    class='adress'
                    title="办卡地点"
                    value-text-align='left'
                    v-model="value"
                    :list="addressData"
                    placeholder="请选择地址"
                    @on-shadow-change='changeAddress'
                    :show.sync="showAddress")
                //- area-select(
                //-   type='text'
                //-   v-model='selected'
                //-   :data="$pcaa"
                //-   :level="3")
                //- area-cascader(
                //-   placeholder="请选择地区"
                //-  v-model='selected2'
                //-  :level='2')
            div(style='width:100%')
                x-input(placeholder='详细地址：如道路、门牌号、楼栋号、单元、室' v-model='detailAddress')
            //- div(
            //-   style="padding:15px 0 13px 20px;")
            //-   div(
            //-   style="display:flex; align-items: center;")
            //-     check-icon(:value.sync="checkIcon")
            //-     div
            //-         span(
            //-           style="color: #9AA1B6;font-size:14px;"
            //-         ) &nbsp;阅读并同意
            //-         span(@click="goProtocol" style="color:#FFDA33 ;font-size:14px;"
            //-       ) 《用户隐私协议》
            div
              div(
                style='width:90%;margin:24px auto 0;border-radius:20px;text-align:center;padding-top:9px;padding-bottom:9px;color:#9AA1B6;background:rgba(255, 218, 51,.3);' v-if='!this.applyMobile || !this.userName || !this.code || !this.doCardTime || !this.value || !this.detailAddress || !this.monthMoney'
              ) 申请
              div(
                style='width:90%;margin:24px auto 0;border-radius:20px;text-align:center;padding-top:9px;padding-bottom:9px;color:#161921;background:#FFDA33;' v-else
                @click='nextStep'
              ) 申请

            //- div(style='width:100%;text-align:center;position:fixed;bottom:10px;' id='footer')
            //-   img(src='@/assets/apply-footer.png' style='width:90%;vertical-align:middle;')
</template>

<script>
// import '@/utils/flexApply'
import { getUrlQueryObj } from '@/utils/index.js'
import { agreementUrl, applyCard, applysendSms, apply, onlineUserInfo } from '@/api'
import { start } from '@/api/assemble-controller.js'
import { offlineapplyCard } from '@/api/offline-apply-controller.js'
import { XAddress, XInput, Countdown, XButton, XDialog, Checklist, CheckIcon, TransferDomDirective as TransferDom, PopupPicker, ChinaAddressV4Data } from 'vux'
export default {
  name: 'ApplyCard',
  directives: {
    TransferDom
  },
  components: {
    XInput,
    Countdown,
    XButton,
    XDialog,
    Checklist,
    CheckIcon,
    XAddress,
    PopupPicker
  },
  data() {
    return {
      local: {
        address: '',
        str: 0,
        doCardTime: 0,
        applyNo: ''
      },
      detailAddress: '',
      formoffline: {
        applyMobile: ''
      },
      showAddress: false,
      addressData: ChinaAddressV4Data,
      value: [],
      selected: [],
      selected2: [],
      userName: '',
      applyMobile: '',
      idCard: '',
      mobile: undefined,
      code: '',
      time: 59,
      show: true,
      start: false,
      disabled: false,
      showModal: false,
      checkIcon: false,
      obj: {},
      doCardTime: [],
      monthMoney: [],
      urlQuery: {},
      monthList: [['5000元以下', '5000-1万元', '1-2万元', '2万元以上']],
      timeList: [['工作日', '周六或周日', '任何时间']]
    }
  },
  computed: {},
  created() {
    this.setDocumentTitle('上门办卡')
    this.$vux.loading.hide()
    this.getDatas()
    this.obj = getUrlQueryObj()
    console.log(90, this.obj)
  },
  methods: {
    initPage() {
      this.fetchData()
    },
    fetchData() {
      const params = {}
      params.bankId = this.bankId
      agreementUrl(params).then(res => {
        this.bankCode = res.resultObj.bankCode
        this.bankId = res.resultObj.bankId
        this.bankName = res.resultObj.bankName
        this.creditAgreement = res.resultObj.creditAgreement
      })
    },
    goProtocol() {
      this.$router.push({
        path: '/serviceProtocol'
      })
    },
    changeMonthmoney(val, names) {
      // console.log('月薪', val, names)
      const key = val[0]
      switch (key) {
        // '5000元以下', '5000-1万元', '1-2万元', '2万元以上'
        case '5000元以下':this.local.str = 1; break
        case '5000-1万元':this.local.str = 2; break
        case '1-2万元':this.local.str = 3; break
        case '2万元以上':this.local.str = 4; break
        default:break
      }
      return this.local.str
    },
    changeDocardTime(val) {
      const key = val[0]
      switch (key) {
        // '工作日', '周六或周日', '任何时间'
        case '工作日':this.local.doCardTime = 0; break
        case '周六或周日':this.local.doCardTime = 1; break
        case '任何时间':this.local.doCardTime = 2; break
        default:break
      }
      return this.local.doCardTime
    },
    changeAddress(ids, names) {
      // console.log('地址', ids, names)
      this.local.address = names.join(' ')
    },
    getDatas() {
      const obj = {}
      obj.userNo = localStorage.getItem('userNo')
      obj.type = 1
      onlineUserInfo(obj).then(res => {
        this.urlQuery = res.resultObj
        this.mobile = this.urlQuery.applyMobile || ''
        this.applyMobile = this.urlQuery.applyMobile || ''
        this.idCard = this.urlQuery.idCard || ''
        this.userName = this.urlQuery.realName || ''
      })
    },
    // 倒计时后处理
    finish(index) {
      this.start = false
      this.show = true
      this.disabled = false
      this.time = 29
    },
    getCode() {
      // alert('12345')
      if (!this.applyMobile) {
        this.$vux.toast.show({
          type: 'cancel',
          text: '请输入手机号'
        })
        return
      } else {
        const params = {}
        params.mobile = (this.applyMobile).replace(/\s*/g, '')
        params.type = 1
        applysendSms(params).then(res => {
          this.start = true
          this.show = false
          this.disabled = true
          this.$vux.toast.show({
            type: 'success',
            text: res.message
          })
        })
      }
    },
    nextStep() {
      // if (!this.userName) {
      //   this.showToast('', 'text', '姓名不能为空')
      //   return
      // }
      // if (!this.idCard) {
      //   this.showToast('', 'text', '身份证号不能为空')
      //   return
      // }
      // if (!this.applyMobile) {
      //   this.showToast('', 'text', '请输入手机号')
      //   return
      // }
      // if (!this.code) {
      //   this.showToast('', 'text', '请输入验证码')
      //   return
      // }
      // if (!this.checkIcon) {
      //   this.showToast('', 'text', '请同意协议')
      //   return
      // }
      const arg = {}
      arg.address = this.local.address + ' ' + this.detailAddress// 办卡地址
      arg.addressType = 0 // 默认公司地址0
      arg.agreementUrl = ''// 协议地址
      arg.applyMobile = (this.applyMobile).replace(/\s*/g, '')
      arg.applyNo = this.obj.applyNo || '' // 申请编号
      arg.bankId = this.obj.bankId// 银行id
      arg.channel = this.obj.channel// 渠道
      arg.code = this.code // 验证码
      arg.creditNo = this.obj.creditNo // 卡种编号
      arg.doCardAddress = 0 // 办卡地点
      arg.doCardTime = this.local.doCardTime // 办卡时间
      arg.mobile = (this.applyMobile).replace(/\s*/g, '') // 登录人手机号
      arg.monthMoney = this.local.str// 月收入
      arg.realName = this.userName // 申请人姓名
      /** 分割线 */
      arg.cid = this.obj.cid// 卡编码
      console.log('参数', arg)
      offlineapplyCard(arg).then(data => {
        if (data.code == 1) {
          this.local.applyNo = data.resultObj.applyNo
          if (this.obj.assembles && this.obj.assembles == 1) {
            this.defaultAssemble()
          } else {
            if (window.Client) {
              window.callShareClient('vSuccess', '')
            } else {
              this.$router.push({
                path: './result'
              })
            }
          }
        } else {
          this.$vux.toast.show({
            type: 'cancel',
            text: data.message
          })
        }
      })
    },
    defaultAssemble() {
      // 调 拼团接口
      const params = {}
      params.applyNo = this.local.applyNo
      params.assembleNo = this.obj.assembleNo
      params.channel = this.obj.channel
      params.creditNo = this.obj.creditNo // 卡种编号
      params.flag = this.obj.flag
      params.mobile = (this.applyMobile).replace(/\s*/g, '')
      params.rewardMoney = this.obj.rewardMoney // 返佣金额
      params.type = 1 // 网申
      start(params).then(res => {
        if (res.code == 1) {
          // 上门办卡成功
          if (window.Client) {
            window.callShareClient('vSuccess', '')
          } else {
            this.$router.push({
              path: './result'
            })
          }
        } else {
          this.$vux.toast.show({
            type: 'cancel',
            text: res.message
          })
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
    .weui-cell:before{
        display: none!important;
    }
    .weui-cells:after{
        display: none!important;
    }
    .weui-cells:before{
        display: none!important;
    }
    .apply-card{
        .weui-input{
          font-size: 16px!important;
          font-family: PingFangSC-Regular, sans-serif;
          font-weight: 500;
        }
        .weui-cell__bd{
          width:60%!important;
        }
        .weui-cells__title{
            font-family: PingFangSC-Medium;
            font-size: 1.125rem;
            color: #333333;
        }
        .modalTrans{
            .weui-cell__bd{
                color: #333333!important;
                text-align: left!important;
                font-size: 0.875rem!important;
            }
        }
        .block-title{
            font-family: PingFangSC-Semibold;
            font-size: 1.25rem;
            color: #333333;
            padding: 1.875rem 0 1rem 0;
            margin:0 1.2rem ;
            border-bottom: 1px solid #f3f3f3;
            font-weight:700
        }
        .contacts{
            .vertCode{
                display: flex;
                justify-content: space-between;
            }
        }
    }
</style>
<style scoped>
.apply-card >>> .weui-icon-circle{
  font-size:14px;
}
.apply-card >>> .weui-cell{
  padding-left:20px;
  padding-top: 15px;
  padding-bottom: 13px;
}
.apply-card >>> .weui-btn{
  line-height: inherit;
}
.apply-card >>> .weui-label{
  font-size:16px;
  color:#3B4257!important;

}
.apply-card >>> .vux-popup-picker-placeholder{
    font-size:16px;
    color:#9AA1B6;
}
.apply-card>>> .weui-icon-success{
  font-size:14px;
  color:#FFDA33;
}
.apply-card >>> .weui-icon-circle:before {
    content: "\EA01";
    color: #FFDA33;
}
.apply-card >>> .vux-check-icon > .weui-icon-success:before, .vux-check-icon > .weui-icon-success-circle:before{
  color: #FFDA33!important;
}
.apply-card >>> .weui-input::placeholder{
  color:#9AA1B6;
  /* color:red/; */
}
input::-webkit-input-placeholder { /* WebKit browsers */
    color:   #9AA1B6;
}
input:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
    color:   #9AA1B6;
}
input::-moz-placeholder { /* Mozilla Firefox 19+ */
    color:   #9AA1B6;
}
input:-ms-input-placeholder { /* Internet Explorer 10+ */
    color:   #9AA1B6;
}
.apply-card >>> .vux-input-icon.weui-icon-warn:before, .vux-input-icon.weui-icon-success:before{
  display: none!important;
}
.apply-card >>> .vux-popup-picker-select{
    padding-left: 44px!important;
}
.time >>> .vux-popup-picker-select{
    padding-left: 29px!important;
}
.adress >>> .vux-popup-picker-select{
    padding-left: 29px!important;
}
.apply-card >>> .vux-label-desc{
    font-size: 10px;
}
</style>

