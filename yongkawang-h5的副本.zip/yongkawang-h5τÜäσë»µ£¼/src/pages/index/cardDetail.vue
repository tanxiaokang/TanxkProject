<template class="container">
  <transition name="slide-left">
    <div class="detail">
      <div class="header">
        <img :src="Query.url" alt="卡图片">
        <span>已拼{{ Query.grantCount }}张</span>
        <!-- <div v-for="(item,ind) in lists" v-show="toastShow" :key="ind">-->
        <!-- <swiper-toast :data-obj="lists[0]" /> -->
        <!-- </div>  -->
        <swiper
          v-if="swiperShow"
          auto
          height="22px"
          direction="vertical"
          :interval="4000"
          class="text-scroll"
          :show-dots="false"
          style=" position: absolute;
          width:80%;
          line-height:22px;
          top:41px;
          background: rgba(59,66,87,.8);
          border-radius: 8px;
          padding:0 4px;
          color: #ffffff;
          font-size: 12px;
          left: 45px;"
          :loop="true"
        >
          <swiper-item v-for="(item,ind) in lists" :key="ind">
            <p style="text-align:center;">
              <img src="@/assets/assemble/swiper.png" alt="" style="width:14px;height:14px;vertical-align:middle;">&nbsp;{{ item.mobile }}用户开卡成功，将获得{{ parseInt(item.rewardMoney) }}元现金红包
            </p>
          </swiper-item>
        </swiper>
      </div>
      <div class="content">
        <p class="content-name">
          {{ Query.creditName }}
        </p>
        <p class="content-hot">
          <Rate :score="Query.recommend" :show-text="false" disabled />
          <span v-if="Query.pass" style="font-size:12px;color:#3B4257;margin-left:10px;">通过率{{ Query.pass }}%</span>
        </p>
        <p class="content-tags">
          <span v-for="(tag,ind) in Query.tagInfo" :key="ind" class="tag" :class="{'bgred':tag.tagName=='上门办理'}">{{ tag.tagName }}</span>
        </p>
        <p class="content-desc">
          {{ Query.cardDesc }}
        </p>
        <div class="content-handle">
          <div>
            <span class="bgred">拼团办卡</span>
            <span class="fontred">银行新开卡用户得{{ Query.commission }}元现金</span>
          </div>
          <span class="rules" @click="handleRules">活动规则</span>
        </div>
      </div>
      <div class="list">
        <div class="list-title">
          <span>{{ Query.assembleNum }}个团等待您加入，可直接参与</span>
          <span v-if="Query.assembleNum" class="rules" @click="handleCheckAll(Query)">查看全部</span>
        </div>
        <div v-for="(item,ind) in queryLists" :key="ind" class="list-div">
          <div>
            <img src="@/assets/assemble/hlogo.png" alt="" style="width:30px;height:30px;vertical-align: middle;">
            <span style="font-size:12px;color:#3B4257;">{{ item.leaderMobile |parseMobile }}</span>
          </div>
          <div style="font-size:12px;color:#3B4257;text-align:right;width:1.34rem;">
            <p>还差<span class="font_red">{{ item.completionNum-item.currentNum }}</span>人成团</p>
            <!-- <p>距结束还剩<span class="time">{{ item.endTime | parseTime }}</span></p> -->
            <p style="display:flex;float:right;">
              距结束还剩<count-down
                style="line-height:18px;"
                class="countdown"
                :current-time="nowTime"
                :start-time="nowTime"
                :end-time="Number(item.endTime)"
                :tip-text="'距结束还剩'"
                :tip-text-end="'距结束还剩'"
                :end-text="'已结束'"
                :day-txt="''"
                :hour-txt="':'"
                :minutes-txt="':'"
                :seconds-txt="''"
                @start_callback="countDownS_cb(1)"
                @end_callback="countDownE_cb()"
              />
            </p>
          </div>
          <div style="color:#fff;background:#F4402E;border-radius:20px;padding:3px 7px;font-size:14px;" @click="handleJoinassemble(item.isNetApply,Query.bankId,item.applySource,item.netApplyAddress,item.creditNo,Query.commission,item.assembleNo,item.assembleType, item.assembles)">
            加入拼团
          </div>
        </div>
      </div>
      <div v-if="footerLists" class="recommend">
        <p style="font-size:14px;color:#000000;">
          推荐
        </p>
        <div class="recommend-lists">
          <div v-for="(item,ind) in footerLists" :key="ind" style="margin-top:12px;" @click="handleToDetail(item.creditNo)">
            <img :src="item.smallUrl" alt="" style="width:96px;height:60px;border-radius:10px;">
            <p style="color:#333333;font-size:12px;margin-top:6px;">
              已拼<countup :start-val="1" :end-val="item.grantCount" :duration="2" class="font_red" :options="{'useGrouping':false}" />张
            </p>
          </div>
        </div>
      </div>
      <div class="public-btn" @click="handleStart()">
        发起拼团
      </div>
    </div>
  </transition>
</template>

<script>
import swiperToast from '@/components/swiperToast.vue'
import CountDown from 'vue2-countdown'
import Rate from '@/components/rate.vue'
import showList from './component/showList.vue'
import { Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup } from 'vux'
import '@/utils/flex.js'
import utils from '@/utils/utils.js'
import { assembleCardInfo, assembleNum, assembleAd, assembleDetailRadio } from '@/api/assemble-controller.js'
import mixins from '@/mixins/index.js'
import startAssemble from '@/mixins/applyOrdoor.js'
export default {
  name: 'Sign',
  components: {
    Swiper, SwiperItem, Marquee, MarqueeItem, Toast, Countup, showList, Rate, CountDown, swiperToast
  },
  filters: {
    parseTime(val) {
      setInterval(() => {
        return utils.changeTimeStamp(val)
      }, 100)
    },
    parseMobile(val) {
      return val.substr(0, 3) + '****' + val.substr(7, 11)
    }
  },
  mixins: [mixins, startAssemble],
  data() {
    return {
      tags: ['上门办理', '吃喝玩乐推荐'],
      time: '',
      local: {
        creditNo: ''
      },
      Query: {},
      queryLists: [{
        leaderMobile: '123456789',
        endTime: 0
      }],
      nowTime: new Date().getTime(),
      footerLists: [],
      lists: [],
      toastShow: true,
      swiperShow: false
    }
  },
  watch: {},
  created() {
    this.init()
    // alert('创建')
    window.appInvokeH5 = this.appInvokeH5
    this.setDocumentTitle('拼团详情页面')
    this.local.creditNo = this.$route.query.creditNo
    this.$uweb.trackEvent(this.Query.creditName, '查看页面')
    console.log('created', this.$route.query.creditNo)
    this.getCardMsg()
    this.getAssembleNum()
    this.getFooter()
    window.callShareClient('swiper', 'true').then(res => {
      console.log('detail', res)
      if (res) {
        this.swiperShow = true// H5 swiper show
        this.getSwiperLists()
        console.log('H5 内部交互')
      } else {
        this.swiperShow = false
      }
    })
  },
  mounted() {},
  destroyed() {
    // alert('销毁')
    window.callShareClient('swiper', 'false')
  },
  methods: {
    init() {
      const obj = {
        title: '用卡王-爱拼才会赢', // 分享标题
        desc: '拼团办理' + this.Query.creditName + '，领现金红包。', // 分享描述
        link: window.location.href, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: 'https://ftp.runzezhihui.com/cycleImage/2019-05-29/i186172451792875520/i186172451792875520.png'
      }
      this.getWxShare(obj)
    },
    handleRules() {
      this.$router.push({
        path: './AssembleRules'
      })
    },
    // 查看全部
    // prams, channel, form, cid, bankId, applySource, netApplyAddress, creditNo, flag, rewardMoney
    handleCheckAll(Query) {
      console.log(190, this.Query)
      this.$router.push({
        path: './AssembleLists',
        query: {
          creditNo: this.Query.creditNo,
          bankId: this.Query.bankId,
          applySource: this.Query.applySource,
          netApplyAddress: this.Query.netApplyAddress,
          flag: this.Query.flag,
          rewardMoney: this.Query.commission
        }
      })
    },
    countDownS_cb: function(x) {
      console.log(1, x)
    },
    // 发起拼团
    handleStart() {
      this.$uweb.trackEvent(this.Query.creditName, '发起拼团')
      console.log('发起拼团', this.Query)
      const isNetApply = this.Query.isNetApply
      const cid = this.Query.cardId
      const pc = this.isPC()
      const bankId = this.Query.bankId
      const applySource = this.Query.applySource
      const netApplyAddress = this.Query.netApplyAddress
      const rewardMoney = this.Query.commission // 返佣金额
      const flag = 0// 发起0   加入 1
      const assembleType = this.Query.assembleType // 是否支持拼团
      const userNo = localStorage.getItem('userNo') // userNo 从哪里给呢
      const assembleNo = ''
      const assembles = this.Query.assembles
      let channel
      if (pc) {
        channel = 'H5-PC-ykw'
      } else {
        channel = this.isMobile()
      }
      // channel, form, cid
      // 通过isNetApply 判断 跳 线上申请 还是 上门办理
      this.jumpToapplyOrDoor(isNetApply, channel, 'ykw', cid, bankId, applySource, netApplyAddress, this.local.creditNo, flag, rewardMoney, assembleNo, this.Query.assembleType, userNo, assembles)
    },
    // 加入拼团
    handleJoinassemble(isNetApply, bankId, applySource, netApplyAddress, creditNo, rewardMoney, assembleNo, assembleType, assembles) {
      this.$uweb.trackEvent(this.Query.creditName, '加入拼团')
      const cid = this.Query.cardId
      const pc = this.isPC()
      const flag = 1
      let channel
      if (pc) {
        channel = 'H5-PC-ykw'
      } else {
        channel = this.isMobile()
      }
      const userNo = localStorage.getItem('userNo')
      this.jumpToapplyOrDoor(isNetApply, channel, 'ykw', cid, bankId, applySource, netApplyAddress, creditNo, flag, rewardMoney, assembleNo, assembleType, userNo, assembles)
    },
    countDownE_cb: function(x) {
      this.endText = '已经结束'
    },
    getCardMsg() {
      assembleCardInfo(this.local.creditNo).then(res => {
        if (res.code == 1) {
          this.Query = res.resultObj
        }
      })
    },
    getAssembleNum() {
      const obj = {}
      obj.pageSize = 1
      obj.rows = 2
      assembleNum(this.local.creditNo, obj).then(res => {
        if (res.code == 1) {
          this.queryLists = res.resultObj.resultObj
        }
      })
    },
    getFooter() {
      const obj = {}
      obj.type = 0
      obj.pageSize = 1
      obj.rows = 3
      assembleAd(obj).then(res => {
        if (res.code == 1) {
          this.footerLists = res.resultObj.resultObj
        }
      })
    },
    handleToDetail(creditNo) {
      this.$router.push({
        path: './cardykwDetail',
        query: {
          creditNo: creditNo

        }
      })
    },
    getSwiperLists() {
      const obj = {}
      obj.userNo = this.getRamNumber()
      assembleDetailRadio(obj.userNo).then(res => {
        if (res.code == 1) {
          this.lists = res.resultObj
        }
      })
    },
    getRamNumber() {
      var result = ''
      for (var i = 0; i < 16; i++) {
        result += Math.floor(Math.random() * 16).toString(16)// 获取0-15并通过toString转16进制
      }
      // 默认字母小写，手动转大写
      return result.toUpperCase()// 另toLowerCase()转小写
    },
    appInvokeH5(type, param) {
      switch (type) {
        case 'shareInfo':
          this.objdesc = {
            qqimageURL: 'https://ftp.runzezhihui.com/cycleImage/2019-05-28/i185809091686899712/i185809091686899712.png', // 事先部署到服务器 qq
            wximageURL: 'https://ftp.runzezhihui.com/cycleImage/2019-05-29/i186172451792875520/i186172451792875520.png', // 事先部署到服务器 wx
            title: '用卡王-爱拼才会赢',
            subtitle: '拼团办理' + this.Query.creditName + '，领现金红包。'
          }
          window.callShareClient('share', JSON.stringify(this.objdesc)); break
      }
    }
  }
}
</script>

<style lang="less" scoped>
@import '~vux/src/styles/reset.less';
*{
    box-sizing: border-box;
}
.public-btn{
  text-align: center;
  color: #fff;
  background: #F4402E;
  font-size: 16px;
  width:3.35rem;
  height: 40px;
  line-height: 40px;
  border-radius: 20px;
 margin: 24px auto;
}
.font_red{
  color: #F4402E;
  font-size:12px;
}
.detail{
  .header{
    padding: 20px;
    text-align: center;
    position: relative;
    border-radius: 10px;
    img{
      width: 3.35rem;
      height: 2.1rem;
      border-radius: 10px;
    }
    span{
      position: absolute;
      display: inline-block;
      width: 1.1rem;
      left: 20px;
      bottom:20px;
      font-size: 14px;
      color: #fff;
      background: linear-gradient(to right,#F4402E,rgba(244,64,46,0.1)) ;
      border-radius:0 0 0 10px;
    }
  }
  .content{
    padding: 0 16px;
    &-name{
      color: #3B4257;
      font-size: 20px;
    }
    &-hot{
      margin:8px 0 16px 0;
      display: flex;
    }
    &-tags{
      font-size: 12px;
      color: #9AA1B6;
      .tag{
        margin-right: 9px;
      }
    }
    &-desc{
      color: #9AA1B6;
      font-size: 12px;
      padding: 13px 0;
    }
    &-handle{
      display: flex;
      align-items: center;
      font-size: 12px;
      justify-content: space-between;
      .fontred{
        color: #F4402E;
        margin-left: 5px;
      }
      .rules{
        color: #9AA1B6;
      }
      .rules::after{
        content:'';
        display: inline-block;
        width:7px;
        height:7px;
        border-top:1px solid#9AA1B6;
        border-right:1px solid#9AA1B6;
        -webkit-transform: translate(0,0%) rotate(45deg);
        transform: translate(0,0%) rotate(45deg);
      }
    }
  }
  .list{
    padding: 30px 16px 0;
    &-title{
      color: #3C4358;
      font-size: 14px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .rules{
        color: #9AA1B6;
        font-size: 12px;
      }
      .rules::after{
        content:'';
        display: inline-block;
        width:7px;
        height:7px;
        border-top:1px solid#9AA1B6;
        border-right:1px solid#9AA1B6;
        -webkit-transform: translate(0,0%) rotate(45deg);
        transform: translate(0,0%) rotate(45deg);
      }
    }
    &-div{
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin:17px auto;
    }
  }
  .recommend{
    padding: 17px 27px 0;
    &-lists{
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}
.bgred{
  background: #F4402E;
  color: #fff;
  padding: 2px 4px;
  border-radius: 4px;
}
.footer{
  text-align: center;
  color: #333333;
  font-size: 12px;
  padding-bottom:18px;
  margin-top:19px;
  position: relative;
}
</style>
<style scoped>
.container .countdown p>i{
  font-style:normal!important;
}
slide-right-enter-active,
.slide-right-leave-active,
.slide-left-enter-active,
.slide-left-leave-active {
  will-change: transform;
  transition: all 500ms;
  position: absolute;
}
.slide-right-enter {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}
.slide-right-leave-active {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-enter {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-leave-active {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}
.vux-slider > .vux-swiper > .vux-swiper-item{
  line-height: 22px;
}
</style>
