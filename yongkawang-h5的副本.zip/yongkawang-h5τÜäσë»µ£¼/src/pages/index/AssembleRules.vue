<template>
  <div class="rules">
    <div>
      <p class="title">
        1.拼团奖励规则：每个银行的返佣金额不同
      </p>
      <p class="content">
        以华夏银行作为例子：
      </p>
      <p class="content">
        (1)拼团人数为1人，开卡成功，得36元；
      </p>
      <p class="content">
        (2)拼团人数为2人，2人开卡成功，每人得48元；
      </p>
      <p class="content">
        (3)拼团人数为2人，1人开卡成功，成功用户得48元，未成功用户得12元；
      </p>
      <p class="content">
        (4)拼团人数为3人，3人开卡成功，成功用户每人得60元；
      </p>
      <p class="content">
        (5)拼团人数为3人，2人开卡成功，成功用户得60元，未成功用户得12元；
      </p>
      <p class="content">
        (6)拼团人数为3人，1人开卡成功，成功用户得60元，未成功用户得12元；
      </p>
      <p class="content">
        (7)发起拼团后，如都未能成功开卡，将每人奖励100金币；
      </p>
      <p class="title">
        2.现金红包奖励发放后，将发放到用卡王我的零钱中，可进行绑卡提现；
      </p>
      <p class="title">
        3.发起拼团24小时后，如无用户加入拼团，将1人成团办卡；
      </p>
      <p class="title">
        4.每人每月奖励限制3次（现金红包+金币）
      </p>
      <p class="title">
        5.本活动规则最终解释权为用卡王所有。
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Protocol',
  data() {
    return {
      bankName: undefined
    }
  },
  created() {
    this.bankName = this.$route.params.id
    this.setDocumentTitle('拼团规则')
  }
}
</script>

<style lang="less" scoped>
     .rules{
       padding:14px 16px;
       p{
         color: #3B4257;
         font-size: 14px;
         line-height: 24px;
       }
       p.title{
         font-weight: 500;
       }
     }
</style>
