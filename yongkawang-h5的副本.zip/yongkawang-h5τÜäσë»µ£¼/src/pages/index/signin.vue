<template>
  <div class="sign">
    <div>
      <div class="title">
        签到规则
        <p @click="jumpTo">
          跳转
        </p>
      </div>
    </div>
  </div>
</template>

<script>
import '@/utils/flex.js'
export default {
  name: 'Sign',
  data() {
    return {

    }
  },
  created() {
    this.setDocumentTitle('签到规则')
  },
  methods: {
    jumpTo() {
      this.$router.push('./signinPage')
    }
  }
}
</script>

<style lang="less" scoped>
@import '~vux/src/styles/reset.less';
     .sign{
         .tip{
             font-family: PingFangSC-Semibold;
             font-size: 0.12rem;
             color: #333333;
             text-align: center;
         }
         .title{
            //  font-weight: bold;
             font-size: 0.16rem;
            //  margin: 1rem 0;
         }
         .content{
           box-sizing: border-box;
             padding: 0 1rem;
             font-size: 0.835rem;
             color:#666666;
             letter-spacing: 2px;
             line-height: 1.4rem;
         }
     }
</style>
