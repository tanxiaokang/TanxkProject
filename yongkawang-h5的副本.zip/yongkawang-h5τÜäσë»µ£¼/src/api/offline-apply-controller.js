import request from '@/utils/request'
import axios from 'axios'
/**
 * 上门办卡  v1.5
 */
// /api/v1/offline/applyCard  申卡
export function offlineapplyCard(params) {
  return request({
    url: '/api/v1/offline/applyCard',
    data: params,
    isToken: 'noToken',
    method: 'post',
    isJson: true
  })
}
