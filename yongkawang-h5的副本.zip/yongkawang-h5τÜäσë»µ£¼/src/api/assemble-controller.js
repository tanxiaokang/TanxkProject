import request from '@/utils/request'
import axios from 'axios'
/**
 * 拼团活动 v1.5
 */
// /api/v1/assemble/assembleAd  拼团类型接口
export function assembleAd(params) {
  return request({
    url: '/api/v1/assemble/assembleAd',
    data: params,
    isToken: 'noToken',
    method: 'post'
  })
}
// /api/v1/assemble/assembleCardInfo/{creditNo}  拼团页面-卡信息
export function assembleCardInfo(arg) {
  return request({
    url: '/api/v1/assemble/assembleCardInfo/' + arg,
    isToken: 'noToken',
    method: 'post',
    isJson: true
  })
}
// /api/v1/assemble/assembleNum/{creditNo}  拼团数
export function assembleNum(arg, params) {
  return request({
    url: '/api/v1/assemble/assembleNum/' + arg,
    isToken: 'noToken',
    data: params,
    method: 'post',
    isJson: false
  })
}
// /api/v1/assemble/start   发起拼团接口
export function start(params) {
  return request({
    url: '/api/v1/assemble/start',
    isToken: 'noToken',
    data: params,
    method: 'post',
    isJson: true
  })
}
/**
 * /api/v1/app/radio/assembleDetailRadio/{userNo}   结束拼团广播
 */
export function assembleDetailRadio(arg) {
  return request({
    url: '/api/v1/app/radio/assembleDetailRadio/' + arg,
    isToken: 'noToken',
    method: 'post',
    isJson: false
  })
}
