import request from '@/utils/request'
import axios from 'axios'
export function agreementUrl(params) {
  return request({
    url: '/api/v1/apply/agreementUrl',
    data: params,
    isToken: 'noToken',
    method: 'post'
  })
}

export function sendSms(parmas) {
  return axios({
    // 接口还是使用原来的端口10002
    method: 'post',
    url: 'http://192.168.123.221:10002/api/v1/apate/sendSms',
    data: parmas,
    isToken: 'noToken'
  })
}

export function applyCard(arg) {
  return request({
    url: '/api/v1/apply/applyCard',
    data: arg,
    isJson: true,
    isToken: 'noToken'
  })
}

// 快捷登录  拆分
export function activityLogin(arg) {
  return request({
    url: 'http://192.168.123.221:10003/api/v1/activity/activityLogin',
    data: arg,
    isJson: false,
    isToken: 'noToken'
  })
}
/**
 *
 * @param {*} arg
 * /api/v1/activity/inviteDetail   邀请好友活动详情 拆分
 */
export function inviteDetail(arg) {
  return request({
    url: 'http://192.168.123.221:10003/api/v1/activity/inviteDetail',
    data: arg,
    isJson: false,
    isToken: 'noToken'
  })
}

// 查询活动资格
export function checkActivity(arg) {
  return request({
    url: 'http://192.168.123.221:10003/api/v1/activity/checkActivity',
    data: arg,
    isJson: false,
    isToken: 'noToken'
  })
}

// 查询拼团状态
export function checkGroup(arg) {
  return request({
    url: '/api/v1/activity/checkGroup',
    data: arg,
    isJson: false,
    isToken: 'noToken'
  })
}
// 查询用户可提现金额
export function getActiveInfo(userNo) {
  return request({
    url: 'http://192.168.123.221:10002/balance/' + userNo,
    isJson: false,
    isToken: 'noToken',
    method: 'get'
  })
}
export function withdraw(params) {
  return request({
    url: '/withdraw',
    data: params,
    isJson: true,
    isToken: 'noToken',
    method: 'post'
  })
}

// 用户绑卡状态
export function getUserBackList(idCard) {
  return request({
    url: 'http://192.168.123.221:10002/api/v1/pay/bindBankCard/list/' + idCard,
    isJson: false,
    isToken: 'noToken',
    method: 'get'
  })
}

// 获取银行列表
export function bindBankCardBank(arg) {
  return request({
    url: 'api/v1/pay/bindBankCard/bank',
    data: arg,
    isJson: false,
    isToken: 'noToken'
  })
}

// 酷宝绑卡(预绑卡发短息)
export function bindBankCardBind(arg) {
  return request({
    url: '/api/v1/pay/bindBankCard/bind',
    data: arg,
    isJson: true,
    isToken: 'noToken'
  })
}

// 重发绑卡验证码
export function bindBankCardCodeResend(ticket) {
  return request({
    url: '/api/v1/pay/bindBankCard/resend/' + ticket,
    isJson: false,
    isToken: 'noToken',
    method: 'get'
  })
}
//  申请信用卡发送验证码

/**
 * /api/v1/online/sendSms
发送快捷登录短信
 *  */

export function applysendSms(arg) {
  return request({
    url: '/api/v1/online/sendSms',
    // isJson: false,
    data: arg,
    isToken: 'noToken',
    method: 'post'
  })
}
/**
 *
 * @param {*} arg
 * /api/v1/online/apply   网申
 */
export function apply(arg) {
  return request({
    url: '/api/v1/online/apply',
    isJson: true,
    data: arg,
    isToken: 'noToken',
    method: 'post'
  })
}
/**
 *
 * @param {*} parmas
 * /api/v1/online/applyAssemble  拼团网申接口
 *
 */
export function applyAssemble(arg) {
  return request({
    url: '/api/v1/online/applyAssemble',
    isJson: true,
    data: arg,
    isToken: 'noToken',
    method: 'post'
  })
}
export function verify(parmas) {
  return request({
    url: '/api/v1/pay/bindBankCard/verify',
    data: parmas,
    isJson: true,
    isToken: 'noToken'
  })
}
export function onlineUserInfo(parmas) {
  return request({
    url: '/api/v1/online/onlineUserInfo',
    data: parmas,
    isJson: false,
    isToken: 'noToken'
  })
}
//  /api/v1/wx/getWXConfigSignature   获取微信签名
export function getWXConfigSignature(parmas) {
  return request({
    url: '/api/v1/wx/getWXConfigSignature ',
    data: parmas,
    isJson: false,
    isToken: 'noToken'
  })
}
/**
 * 拼团活动 v1.5
 */
// /api/v1/assemble/assembleAd  拼团类型接口
